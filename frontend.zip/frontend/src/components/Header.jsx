
// src/components/Header.jsx
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();

  // Function for Admin Login with tab param
  function goLoginWithTab(tab) {
    const params = new URLSearchParams(location.search);
    params.set("tab", tab);
    navigate(`/login?${params.toString()}`);
  }

  // Role-based path
  const roleToPath = (role) => {
    if (role === "buyer") return "/customer";
    if (role === "seller") return "/seller";
    if (role === "admin") return "/manager";
    return "/";
  };

  return (
    <header className="home-header">
      {/* Brand Section */}
      <div className="brand">
        <div className="logo">S</div>
        <div className="brand-text">
          <h1>Products Review System</h1>
          <p className="tagline">Your unified commerce portal</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="nav">
        <NavLink to="/" className="link">Home</NavLink>
        <NavLink to="/about" className="link">About</NavLink>

        {!user && (
          <>
            <NavLink to="/login" className="link">Login</NavLink>
            <NavLink to="/register" className="link">Register</NavLink>
            {/* Admin Login Button from first header */}
            <button
              className="link"
              style={{ background: "transparent", border: "none", cursor: "pointer" }}
              onClick={() => goLoginWithTab("admin")}>Admin Login
            </button>
          </>
        )}

        {user && (
          <>
            <NavLink to={roleToPath(user.role)} className="link">
              {user.role === "buyer" ? "Customer" : user.role === "seller" ? "Seller" : "Manager"}
            </NavLink>

            {/* Extra links based on role */}
            {user.role === "seller" && (
              <NavLink to="/seller/products" className="link">Products</NavLink>
            )}
            {user.role === "admin" && (
              <NavLink to="/admin-approvals" className="link">Approvals</NavLink>
            )}

            {/* Logout */}
            <button
              className="link"
              style={{ background: "transparent", border: "none", cursor: "pointer" }}
              onClick={() => { logout(); navigate("/"); }}
              aria-label="Logout"
            >
              Logout ({user.email})
            </button>
          </>
        )}
      </nav>
    </header>
  );
}
