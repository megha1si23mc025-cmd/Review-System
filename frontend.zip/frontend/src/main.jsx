
// src/main.jsx
import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";

import App from "./App";
import Home from "./pages/Home";
import LoginPage from "./pages/LoginPage";
import Customer from "./pages/Customer";
import Seller from "./pages/Seller";
import SellerProducts from "./pages/SellerProducts";
import SellerProductDetails from "./pages/SellerProductDetails";  // <-- add this import
import ProductDetails from "./pages/ProductDetails";              // customer page stays as-is
import Support from "./pages/Support";
import Manager from "./pages/Manager";
import About from "./pages/About";
import Register from "./pages/Register";
import AdminApprovals from "./pages/AdminApprovals";

const rootEl = document.getElementById("root");

createRoot(rootEl).render(
  <BrowserRouter>
    <AuthProvider>
      <Routes>
        {/* App must render an <Outlet /> inside to switch pages */}
        <Route element={<App />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<Register />} />

          {/* Customer */}
          <Route path="/customer" element={<Customer />} />

          {/* Seller */}
          <Route path="/seller" element={<Seller />} />
          <Route path="/seller/products" element={<SellerProducts />} />
          <Route path="/seller/product/:id" element={<SellerProductDetails />} /> {/* <-- new seller details */}

          {/* Customer-facing product details */}
          <Route path="/product-details/:id" element={<ProductDetails />} />

          {/* Support & Admin */}
          <Route path="/support" element={<Support />} />
          <Route path="/manager" element={<Manager />} />
          <Route path="/admin-approvals" element={<AdminApprovals />} />

          {/* Optional: 404 */}
          {/* <Route path="*" element={<NotFound />} /> */}
        </Route>
      </Routes>
    </AuthProvider>
  </BrowserRouter>
);
