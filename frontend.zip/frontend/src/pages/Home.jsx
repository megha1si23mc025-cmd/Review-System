// src/pages/Home.jsx
import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../components/Header";

export default function Home({ currentUser = null }) {
  // Local sample, aligned with backend shape
  const products = [
    {
      id: "p1",
      product_id: "p1",
      name: "Aero Laptop 14",
      productName: "Aero Laptop 14",
      brand: "ZenTech",
      price: 69990,
      rating: 4.4,
      reviews: 128,
      image: "https://via.placeholder.com/800x600?text=Aero+Laptop+14",
      imageUrl: "https://via.placeholder.com/800x600?text=Aero+Laptop+14",
      tag: "New",
    },
    {
      id: "p2",
      product_id: "p2",
      name: "Nimbus Earbuds Pro",
      productName: "Nimbus Earbuds Pro",
      brand: "AudioCore",
      price: 8999,
      rating: 4.1,
      reviews: 342,
      image: "https://via.placeholder.com/800x600?text=Nimbus+Earbuds+Pro",
      imageUrl: "https://via.placeholder.com/800x600?text=Nimbus+Earbuds+Pro",
      tag: "Top Rated",
    },
    {
      id: "p3",
      product_id: "p3",
      name: "Vista Monitor 27\" 4K",
      productName: "Vista Monitor 27\" 4K",
      brand: "ZenTech",
      price: 27999,
      rating: 4.6,
      reviews: 89,
      image: "https://via.placeholder.com/800x600?text=Vista+27+4K",
      imageUrl: "https://via.placeholder.com/800x600?text=Vista+27+4K",
      tag: "4K",
    },
  ];

  const navigate = useNavigate();

  // Search term (centered row under subtitle)
  const [searchTerm, setSearchTerm] = useState("");

  // Filter (includes; supports productName or name)
  const filteredProducts = useMemo(() => {
    const needle = searchTerm.trim().toLowerCase();
    if (!needle) return products;
    return products.filter((p) =>
      ((p.productName || p.name || "")).toLowerCase().includes(needle)
    );
  }, [products, searchTerm]);

  // Product click handler (your logic)
  const handleProductClick = (product) => {
    if (!currentUser) {
      navigate("/login", { state: { redirect: "/buyer-dashboard", product } });
    } else {
      navigate(`/product-details/${product.product_id}`, { state: { product } });
    }
  };

  return (
    <div className="home">
      {/* Inline theme + layout + refined card styles */}
      <style>{
      `
        :root{
          --bg:#0b1020; --bg2:#0e1630; --text:#e5e7eb; --muted:#a2b1c7; --link:#7aa2ff;
          --primary:#3b82f6; --accent:#60a5fa; --success:#1bd6a8;
          --cardBg:rgba(17, 25, 40, 0.55); --cardBorder:rgba(148,163,184,0.12);
          --cardHoverBorder:rgba(148,163,184,0.25);
          --imgBg:#0b1222; --badgeBorder:#1f2a44;
          --starOn:#f59e0b; --starOff:#6b7280;
          /* Search bar palette */
          --sb-bg:#0d1a38; --sb-pill:#0a1530; --sb-border:#1d2b4d; --sb-text:#e8eefc;
          --sb-ph:#9fb0d1; --sb-btn:#f3a847; --sb-btn-hover:#f08804; --sb-outline:rgba(243,168,71,.35);
        }
        body,.home{background:radial-gradient(1200px 800px at 20% -10%, var(--bg2), var(--bg)); color:var(--text);}

        .container{max-width:1100px; margin:0 auto; padding:0 20px;}
        .hero{padding:48px 0 24px;}
        .stack{display:flex; flex-direction:column; align-items:flex-start; gap:12px;}
        .headline{margin:0; font-size:clamp(28px,4vw,44px); font-weight:800; line-height:1.12; letter-spacing:-.3px;}
        .gradient{background:linear-gradient(90deg,#60a5fa,#34d399,#a78bfa); -webkit-background-clip:text; background-clip:text; color:transparent;}
        .subtitle{margin:0; color:var(--muted); max-width:760px;}

        /* Search row directly under subtitle */
        .search-row{display:flex; align-items:center; gap:10px; margin-top:8px; width:100%; max-width:720px;}
        .searchbar{flex:1; display:grid; grid-template-columns:auto 1fr auto; align-items:stretch;
          background:var(--sb-bg); border:1px solid var(--sb-border); border-radius:999px; height:44px;
          overflow:hidden; box-shadow:0 1px 2px rgba(0,0,0,.3);}
        .searchbar:focus-within{box-shadow:0 0 0 3px var(--sb-outline);}
        .sb-cat{display:inline-flex; align-items:center; gap:6px; padding:0 12px; border:none; border-right:1px solid var(--sb-border);
          background:var(--sb-pill); color:var(--sb-text); font-size:.9rem; cursor:default;}
        .sb-cat svg{opacity:.7;}
        .sb-input{border:none; outline:none; padding:0 12px; font-size:1rem; color:var(--sb-text); background:transparent;}
        .sb-input::placeholder{color:var(--sb-ph);}
        .sb-submit{display:grid; place-items:center; min-width:52px; padding:0 14px; border:none; background:var(--sb-btn); color:#111; cursor:pointer;}
        .sb-submit:hover{background:var(--sb-btn-hover);}
        .sb-icon{display:block;}
        .sb-clear{align-self:center; background:transparent; border:none; color:var(--muted);
          text-decoration:underline; cursor:pointer; padding:6px 8px; height:44px; display:inline-flex; align-items:center;}
        .sb-clear:enabled{color:var(--link);} .sb-clear:disabled{opacity:.45; cursor:not-allowed;}

        /* Get Started button lives BELOW the search bar */
        .cta-row{margin-top:10px;}
        .btn.primary{background:var(--primary); color:#fff; padding:10px 16px; border-radius:10px; text-decoration:none; display:inline-block;}

        /* Section layout */
        .products-section{padding:12px 0 40px;}
        .products-header h3{margin:16px 0 12px;}

        /* --- Product card refresh --- */
        .product-grid{display:grid; grid-template-columns:repeat(auto-fill, minmax(260px,1fr)); gap:18px; margin-top:10px;}
        .product-card{
          background:var(--cardBg);
          border:1px solid var(--cardBorder);
          border-radius:18px;
          overflow:hidden;
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
          transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
          box-shadow: 0 6px 18px rgba(0,0,0,.25);
        }
        .product-card:hover{
          transform: translateY(-4px);
          border-color: var(--cardHoverBorder);
          box-shadow: 0 10px 24px rgba(0,0,0,.35);
        }

        .product-media{
          position:relative;
          background:var(--imgBg);
          aspect-ratio: 16/10;           /* consistent image area */
          overflow:hidden;
        }
        .product-media img{
          width:100%; height:100%; object-fit:cover;
          display:block;
        }
        .pill{
          position:absolute; top:10px; left:10px;
          background:rgba(96,165,250,.12);
          color:#cfe3ff;
          border:1px solid var(--badgeBorder);
          font-size:12px; padding:4px 8px; border-radius:999px; backdrop-filter: blur(4px);
        }

        .product-body{padding:14px;}
        .product-title{margin:0 0 6px; font-weight:700; color:#fff; font-size:1rem;}
        .product-brand{margin:0 0 10px; color:#c4d0e6; font-size:.9rem;}
        .product-meta{display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;}
        .price{color:var(--success); font-weight:800;}
        .rating{display:flex; align-items:center; gap:6px; color:#fde68a;}
        .stars{letter-spacing:1px;}
        .star{color:var(--starOff);} .star.on{color:var(--starOn);}
        .rating-value{color:#fef3c7; font-weight:600;}
        .muted{color:var(--muted);}

        .product-actions{display:flex; gap:8px;}
        .btn.small{padding:8px 12px; background:#1d4ed8; color:#fff; border:none; border-radius:10px; text-decoration:none; font-size:.9rem;}
        .btn.small.ghost{background:transparent; border:1px solid rgba(148,163,184,.2); color:#dbe6ff;}

        /* Make buttons not shift layout when clicking card */
        .product-actions .btn{cursor:pointer;}

        @media (max-width:640px){
          .search-row{max-width:100%;}
        }
      `}</style>

      {/* Keep your global header if present */}
      <Header />

      
<section className="hero">
  <h2>
    A single place for <span className="gradient-text">Customers</span>,{" "}
    <span className="gradient-text">Sellers</span> &amp;{" "}
    <span className="gradient-text">Managers</span>
  </h2>

  <p className="subtitle">
    Track orders, manage products, and monitor KPIs with a delightful, high‑performance UI.
  </p>

  {/* <div className="search-row">
    <form
      role="search"
      aria-label="Search products by name"
      className="searchbar"
      onSubmit={(e) => e.preventDefault()}
    >
      <button type="button" className="sb-cat" disabled title="All categories" aria-label="Category (All)">
        All
        <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d="M7 10l5 5 5-5z" />
        </svg>
      </button>

      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search products… (e.g., Aero, Nimbus, Vista)"
        className="sb-input"
      />

      <button type="submit" className="sb-submit" aria-label="Search">
        <svg className="sb-icon" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path
            fill="currentColor"
            d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 5L20.49 19l-5-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"
          />
        </svg>
      </button>
    </form>

    <button
      type="button"
      className="sb-clear"
      onClick={() => setSearchTerm("")}
      disabled={!searchTerm}
      title="Clear search"
    >
      Clear
    </button>
  </div> */}

  <div className="cta-row">
    <Link
      to="/login"
      className="btn primary"
      style={{
        background: "var(--primary)",
        color: "#fff",
        padding: "10px 16px",
        borderRadius: 8,
        textDecoration: "none",
      }}
    >
      Get Started
    </Link>
  </div>
</section>


      {/* Products section */}
      <section className="products-section">
        <div className="container">
          <div className="products-header">
            <h3>Featured Products</h3>
          </div>

          <div className="product-grid">
            {filteredProducts.length > 0 ? (
              filteredProducts.map((product) => (
                <ProductCard
                  key={product.product_id || product.id}
                  product={product}
                  onClick={() => handleProductClick(product)}
                />
              ))
            ) : (
              <p className="muted">No products match “{searchTerm}”.</p>
            )}
          </div>
        </div>
      </section>

      {/* Roles */}
      <section id="roles" className="roles">
        <div className="container">
          <h3>Choose your space</h3>
          <div className="role-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 12 }}>
            <RoleCard title="Customer" description="Track orders, write reviews, and manage your profile." to="/login" emoji="🧑‍💻" accent="var(--accent)" />
            <RoleCard title="Seller" description="Manage products, inventory, and pricing in real time." to="/login" emoji="🛍️" accent="var(--accent)" />
            <RoleCard title="Manager" description="Monitor KPIs, reports, and team performance." to="/login" emoji="🧭" accent="var(--accent)" />
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="container">
          <p>© {new Date().getFullYear()} Sprint Project • Built with Vite + React</p>
        </div>
      </footer>
    </div>
  );
}

function ProductCard({ product, onClick }) {
  const { name, productName, brand, price, rating, reviews, image, imageUrl, tag } = product;
  const title = productName || name || "Product";
  const imgSrc = imageUrl || image || "https://via.placeholder.com/800x600?text=Product";

  return (
    <article className="product-card" aria-label={`${title} by ${brand || ""}`}>
      <div className="product-media">
        {tag && <span className="pill">{tag}</span>}
        <img
          src={imgSrc}
          alt={`${title} by ${brand || ""}`}
          loading="lazy"
          onError={(e) => { e.currentTarget.src = "https://via.placeholder.com/800x600?text=No+Image"; }}
        />
      </div>

      <div className="product-body">
        <h4 className="product-title" title={title}>{title}</h4>
        <p className="product-brand">{brand}</p>

        <div className="product-meta">
          <span className="price">₹{Number(price || 0).toFixed(2)}</span>
          <span className="rating" aria-label={`${rating ?? 0} out of 5 stars`}>
            <span className="stars">
              {renderStars(rating)}
            </span>
            <span className="rating-value">{(Number(rating) || 0).toFixed(1)}</span>
            <span className="muted">({reviews ?? 0})</span>
          </span>
        </div>

        <div className="product-actions">
          <button className="btn small" onClick={onClick}>View</button>
          <Link to="/login" className="btn small ghost">Review</Link>
        </div>
      </div>
    </article>
  );
}

function RoleCard({ title, description, to, emoji, accent }) {
  return (
    <Link to={to} className="role-card" style={{ "--accent": accent, textDecoration: "none" }}>
      <div className="role-emoji" aria-hidden style={{ fontSize: 28 }}>{emoji}</div>
      <div className="role-info">
        <h4 style={{ margin: 0 }}>{title}</h4>
        <p style={{ margin: "4px 0 6px", color: "var(--muted)" }}>{description}</p>
        <span className="role-cta" style={{ color: "var(--link)" }}>Enter {title} space →</span>
      </div>
    </Link>
  );
}

function renderStars(rating = 0) {
  const r = Math.round(Number(rating) || 0);
  return (
    <>
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < r ? "star on" : "star"} aria-hidden>★</span>
      ))}
    </>
  );
}
