// src/pages/Manager.jsx
import { useEffect, useMemo, useState } from "react";
import Header from "../components/Header";
import { getJSON } from "../api";

export default function Manager() {
  const [products, setProducts] = useState([]);
  const [productId, setProductId] = useState("");
  const [minStars, setMinStars] = useState(0);

  const [avgRating, setAvgRating] = useState(0);
  const [urgent, setUrgent] = useState([]);
  const [trend, setTrend] = useState([]);          // sentiment trend raw points
  const [keyIssues, setKeyIssues] = useState([]);  // top recurring issues
  const [platforms, setPlatforms] = useState([]);  // kept in logic, not shown in UI
  const [mismatches, setMismatches] = useState([]);// rating vs sentiment mismatch
  const [totalReviews, setTotalReviews] = useState(0);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getJSON("/products", { limit: 100 })
      .then((rows) => {
        setProducts(rows || []);
        if (rows?.length) setProductId(rows[0].id);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!productId) return;

    setLoading(true);

    // Average rating (from buyer summary)
    getJSON(`/buyer/product/${productId}/summary`)
      .then((sum) => setAvgRating(Number(sum?.average_rating || 0)))
      .catch(() => setAvgRating(0));

    // Urgent feed
    getJSON(`/support/product/${productId}/urgent`)
      .then((list) => setUrgent(list?.items || []))
      .catch(() => setUrgent([]));

    // Sentiment trend (daily counts)
    getJSON(`/dashboards/product/${productId}/sentiment-trend`)
      .then((res) => setTrend(res?.points || []))
      .catch(() => setTrend([]));

    // Top recurring issues (key themes)
    getJSON(`/dashboards/product/${productId}/key-issues`)
      .then((res) => setKeyIssues(res?.items || []))
      .catch(() => setKeyIssues([]));

    // Reviews (total & mismatches; platform calc kept but not displayed)
    getJSON(`/reviews/product/${productId}`)
      .then((reviews) => {
        const list = reviews || [];
        setTotalReviews(list.length);

        // platform breakdown (not rendered, but left intact)
        const bySource = new Map();
        for (const r of list) {
          const s = (r.source || "web").toLowerCase();
          bySource.set(s, (bySource.get(s) || 0) + 1);
        }
        const platformList = Array.from(bySource.entries())
          .map(([label, count]) => ({ label, count }))
          .sort((a, b) => b.count - a.count);
        setPlatforms(platformList);

        // rating vs sentiment mismatch (heuristic)
        const mm = [];
        for (const r of list) {
          const rating = r.rating;
          if (rating == null) continue;
          const text = (r.review_text || "").toLowerCase();
          const textNeg = /\b(bad|poor|hate|terrible|awful|worse|issue|problem|defect)\b/.test(text);
          if (rating >= 4 && textNeg) {
            mm.push({
              rating,
              text: r.review_text?.slice(0, 140) || "(no text)",
              date: r.review_date,
            });
          }
        }
        setMismatches(mm);
      })
      .catch(() => {
        setPlatforms([]);
        setMismatches([]);
        setTotalReviews(0);
      })
      .finally(() => setLoading(false));

  }, [productId]);

  const product = useMemo(() => products.find(p => String(p.id) === String(productId)), [products, productId]);

  const filteredUrgent = useMemo(() => {
    const arr = urgent.filter(x => (x.rating || 0) >= minStars);
    return arr.sort((a, b) => (a.review_date < b.review_date ? 1 : -1));
  }, [urgent, minStars]);

  // Aggregate sentiment distribution
  const sentimentDistribution = useMemo(() => {
    const bucket = { positive: 0, neutral: 0, negative: 0, unknown: 0 };
    for (const p of trend || []) {
      bucket[p.sentiment] = (bucket[p.sentiment] || 0) + p.count;
    }
    return bucket;
  }, [trend]);

  // Recent trend compact: last 14 days
  const recentTrend = useMemo(() => {
    const last = (trend || []).slice(-42);
    const days = new Map(); // date -> { positive, neutral, negative, unknown }
    for (const pt of last) {
      const d = pt.date;
      if (!days.has(d)) days.set(d, { positive: 0, neutral: 0, negative: 0, unknown: 0 });
      days.get(d)[pt.sentiment] += pt.count;
    }
    const sorted = Array.from(days.entries()).sort((a, b) => (a[0] < b[0] ? -1 : 1));
    return sorted.slice(-14); // [ [date, {..}], ...]
  }, [trend]);

  return (
    <div className="page manager-page">
      <Header />
      <main className="container">
        {/* Admin theme & styles */}
        <style>{`
          :root {
            --bg: #0b1020;
            --bg2: #0e1630;
            --card: #0f172a;
            --cardBorder: #1f2937;
            --text: #e5e7eb;
            --muted: #9fb0d1;
            --accent: #60a5fa;
            --green: #34d399;
            --yellow: #f59e0b;
            --red: #f87171;
            --gray: #9ca3af;
          }
          body, .manager-page {
            background: radial-gradient(1200px 800px at 20% -10%, var(--bg2), var(--bg));
            color: var(--text);
          }
          .container { width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px; }

          /* Controls */
          .controls {
            margin: 16px 0;
            padding: 16px;
            border: 1px solid var(--cardBorder);
            border-radius: 12px;
            background: var(--card);
            box-shadow: 0 1px 3px rgba(0,0,0,.25);
          }
          .controls h3 { margin: 0 0 10px; }
          .row { display: flex; gap: 10px; flex-wrap: wrap; }
          .form-control.select-control {
            height: 40px; padding: 0 12px;
            border-radius: 10px; border: 1px solid var(--cardBorder);
            background: #0b1222; color: var(--text);
          }

          /* Grid layout */
          .grid {
            display: grid;
            grid-template-columns: 1.2fr 1fr;
            gap: 16px;
          }
          @media (max-width: 960px) {
            .grid { grid-template-columns: 1fr; }
          }

          /* Cards */
          .card {
            padding: 16px;
            border: 1px solid var(--cardBorder);
            border-radius: 12px;
            background: var(--card);
            box-shadow: 0 1px 3px rgba(0,0,0,.25);
          }
          .p-header {
            display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            padding-bottom: 10px; margin-bottom: 12px;
          }
          .p-header h4 { margin: 0; }
          .p-header .muted { color: var(--muted); }
          .p-header .meta { display: flex; align-items: baseline; gap: 16px; }
          .price { color: var(--green); font-weight: 700; }

          /* KPI cards */
          .kpi-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px; margin-bottom: 12px;
          }
          @media (max-width: 960px) { .kpi-row { grid-template-columns: repeat(2, 1fr); } }
          .kpi {
            background: #0b1222; border: 1px solid var(--cardBorder);
            padding: 12px; border-radius: 10px;
          }
          .kpi .label { color: var(--muted); font-size: .9rem; }
          .kpi .value { font-size: 1.6rem; font-weight: 800; margin-top: 4px; }

          /* Chart containers */
          .chart-box { background: #0b1222; border: 1px solid var(--cardBorder); border-radius: 10px; padding: 12px; }
          .chart-title { margin: 0 0 8px; font-size: 1rem; color: var(--muted); }
          .legend { display:flex; gap:12px; margin-top:6px; color: var(--muted); font-size:.9rem; }
          .legend .sw { display:inline-block; width:12px; height:12px; border-radius:3px; margin-right:6px; }

          /* Lists */
          .list { margin: 0; padding-left: 18px; }
          .hint { color: var(--muted); }

          /* Reviews list */
          .review-list .review-row {
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 10px; padding: 10px; margin: 8px 0;
            background: #0b1222;
          }
          .review-head { display:flex; align-items:center; justify-content:space-between; }
          .stars { color: #f59e0b; }
          .star { color: #6b7280; }
          .star.on { color: #f59e0b; }
          .rating-value { color: #fef3c7; margin-left: 6px; font-weight: 600; }
        `}</style>

        {/* Controls */}
        <section className="controls card">
          <h3>Product insights (Admin / Manager)</h3>
          <div className="row">
            <select
              className="form-control select-control"
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              aria-label="Select product"
            >
              {products.map(p => (
                <option key={p.id} value={p.id}>
                  {p.product_title} — {p.brand}
                </option>
              ))}
            </select>
            <select
              className="form-control select-control"
              value={minStars}
              onChange={(e) => setMinStars(Number(e.target.value))}
              aria-label="Filter reviews by rating"
            >
              <option value={0}>All ratings</option>
              <option value={3}>3★+</option>
              <option value={4}>4★+</option>
              <option value={5}>5★ only</option>
            </select>
          </div>
        </section>

        {product && (
          <section className="grid">
            {/* Left: header + KPIs + line chart + urgent list */}
            <div className="card">
              <header className="p-header">
                <div>
                  <h4>{product.product_title}</h4>
                  <p className="muted">Brand: <strong>{product.brand || "—"}</strong></p>
                </div>
                <div className="meta">
                  <span className="rating">{renderStars(avgRating)} <span className="muted">({filteredUrgent.length} urgent)</span></span>
                  <span className="price">{product.price != null ? `₹${Number(product.price).toFixed(2)}` : "—"}</span>
                </div>
              </header>

              {/* KPI row */}
              <div className="kpi-row">
                <div className="kpi">
                  <div className="label">Average rating</div>
                  <div className="value">{Number(avgRating || 0).toFixed(1)}★</div>
                </div>
                <div className="kpi">
                  <div className="label">Urgent reviews</div>
                  <div className="value">{filteredUrgent.length}</div>
                </div>
                <div className="kpi">
                  <div className="label">Total reviews</div>
                  <div className="value">{totalReviews}</div>
                </div>
                <div className="kpi">
                  <div className="label">Mismatches (heuristic)</div>
                  <div className="value">{mismatches.length}</div>
                </div>
              </div>

              {/* Sentiment trend chart */}
              <div className="chart-box" aria-label="Sentiment trends (recent)">
                <h5 className="chart-title">Sentiment trends (last 14 days)</h5>
                <LineTrendChart data={recentTrend} width={680} height={220} />
                <div className="legend">
                  <span><span className="sw" style={{ background: "var(--green)" }} />Positive</span>
                  <span><span className="sw" style={{ background: "var(--yellow)" }} />Neutral</span>
                  <span><span className="sw" style={{ background: "var(--red)" }} />Negative</span>
                </div>
              </div>

              {/* Urgent list */}
              <div className="review-list" style={{ marginTop: 12 }}>
                <h5>Urgent reviews</h5>
                {filteredUrgent.length === 0 && <p className="hint">No urgent reviews match the filter.</p>}
                {filteredUrgent.map(r => (
                  <article key={r.review_id} className="review-row">
                    <div className="review-head">
                      <strong>{r.reviewer_name || "Anonymous"}</strong>
                      <span className="stars">{renderStars(r.rating || 0)}</span>
                    </div>
                    <p className="review-text" style={{ margin: "6px 0" }}>{r.excerpt}</p>
                    <span className="muted">{r.review_date}</span>
                  </article>
                ))}
              </div>
            </div>

            {/* Right: donut + issues + mismatches (NO cross‑platform chart) */}
            <div className="card">
              {/* Donut distribution */}
              <div className="chart-box" aria-label="Sentiment distribution">
                <h5 className="chart-title">Sentiment distribution</h5>
                <DonutChart
                  values={[
                    { label: "Positive", value: sentimentDistribution.positive || 0, color: "var(--green)" },
                    { label: "Neutral",  value: sentimentDistribution.neutral  || 0, color: "var(--yellow)" },
                    { label: "Negative", value: sentimentDistribution.negative || 0, color: "var(--red)" },
                    { label: "Unknown",  value: sentimentDistribution.unknown  || 0, color: "var(--gray)" },
                  ]}
                  size={220}
                  thickness={28}
                />
                <div className="legend">
                  <span><span className="sw" style={{ background: "var(--green)" }} />Positive</span>
                  <span><span className="sw" style={{ background: "var(--yellow)" }} />Neutral</span>
                  <span><span className="sw" style={{ background: "var(--red)" }} />Negative</span>
                  <span><span className="sw" style={{ background: "var(--gray)" }} />Unknown</span>
                </div>
              </div>

              {/* Key issues */}
              <div className="chart-box" style={{ marginTop: 12 }}>
                <h5 className="chart-title">Top recurring issues</h5>
                {keyIssues.length === 0 && <p className="hint">—</p>}
                {keyIssues.length > 0 && (
                  <ul className="list">
                    {keyIssues.map((k) => (
                      <li key={k.label}><strong>{k.label}</strong> — {k.count}</li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Mismatches */}
              <div className="chart-box" style={{ marginTop: 12 }}>
                <h5 className="chart-title">Rating vs sentiment mismatch (heuristic)</h5>
                {mismatches.length === 0 && <p className="hint">—</p>}
                {mismatches.length > 0 && (
                  <ul className="list">
                    {mismatches.map((m, i) => (
                      <li key={i}>[{m.date}] {m.rating}★ — {m.text}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </section>
        )}

        {loading && (
          <p className="hint" style={{ marginTop: 12 }}>Loading insights…</p>
        )}
      </main>
    </div>
  );
}

/* ----------------- Charts (pure SVG, no external libs) ------------------ */

function LineTrendChart({ data, width = 680, height = 220, padding = 24 }) {
  // data: [ [date, {positive, neutral, negative, unknown}], ... ]
  const labels = data.map(d => d[0]);
  const series = {
    positive: data.map(d => d[1].positive || 0),
    neutral:  data.map(d => d[1].neutral  || 0),
    negative: data.map(d => d[1].negative || 0),
  };
  const maxY = Math.max(
    1,
    ...series.positive, ...series.neutral, ...series.negative
  );
  const xCount = Math.max(labels.length, 1);
  const innerW = width - padding * 2;
  const innerH = height - padding * 2;

  const x = (i) => padding + (xCount <= 1 ? innerW / 2 : (innerW * i) / (xCount - 1));
  const y = (v) => padding + innerH - (innerH * v) / maxY;

  const pathFor = (arr) =>
    arr.map((v, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(v)}`).join(" ");

  const gridY = 4;
  const grid = [...Array(gridY + 1)].map((_, i) => {
    const gy = padding + (innerH * i) / gridY;
    return gy;
  });

  return (
    <svg width={width} height={height} role="img" aria-label="Line chart of sentiment trends">
      {/* Grid */}
      {grid.map((gy, idx) => (
        <line key={idx} x1={padding} x2={padding + innerW} y1={gy} y2={gy} stroke="rgba(255,255,255,0.08)" />
      ))}
      {/* Axes ticks (x labels) */}
      {labels.map((lab, i) => (
        <text key={lab} x={x(i)} y={height - 6} fill="var(--muted)" fontSize="10" textAnchor="middle">
          {lab}
        </text>
      ))}
      {/* Series */}
      <path d={pathFor(series.positive)} stroke="var(--green)" strokeWidth="2" fill="none" />
      <path d={pathFor(series.neutral)}  stroke="var(--yellow)" strokeWidth="2" fill="none" />
      <path d={pathFor(series.negative)} stroke="var(--red)" strokeWidth="2" fill="none" />
      {/* Points */}
      {series.positive.map((v, i) => (
        <circle key={`p-${i}`} cx={x(i)} cy={y(v)} r="2.8" fill="var(--green)" />
      ))}
      {series.neutral.map((v, i) => (
        <circle key={`n-${i}`} cx={x(i)} cy={y(v)} r="2.8" fill="var(--yellow)" />
      ))}
      {series.negative.map((v, i) => (
        <circle key={`ne-${i}`} cx={x(i)} cy={y(v)} r="2.8" fill="var(--red)" />
      ))}
    </svg>
  );
}

function DonutChart({ values, size = 220, thickness = 28 }) {
  // values: [{label, value, color}]
  const total = Math.max(1, values.reduce((s, v) => s + (v.value || 0), 0));
  const cx = size / 2, cy = size / 2;
  const rOuter = size / 2 - 6;
  const rInner = rOuter - thickness;
  let start = 0;

  const arcs = values.map((v, idx) => {
    const pct = (v.value || 0) / total;
    const end = start + pct * 2 * Math.PI;
    const path = donutArcPath(cx, cy, rInner, rOuter, start, end);
    const item = { path, color: v.color, label: v.label, value: v.value };
    start = end;
    return item;
  });

  return (
    <svg width={size} height={size} role="img" aria-label="Donut chart of sentiment distribution">
      <circle cx={cx} cy={cy} r={rOuter} fill="rgba(255,255,255,0.03)" />
      {arcs.map((a, i) => (
        <path key={i} d={a.path} fill={a.color} stroke="none" />
      ))}
      {/* center label */}
      <circle cx={cx} cy={cy} r={rInner - 2} fill="var(--card)" />
      <text x={cx} y={cy} fill="var(--muted)" fontSize="12" textAnchor="middle" dominantBaseline="middle">
        total {total}
      </text>
    </svg>
  );
}

function donutArcPath(cx, cy, rInner, rOuter, startAngle, endAngle) {
  const oa1 = polarToCartesian(cx, cy, rOuter, startAngle);
  const oa2 = polarToCartesian(cx, cy, rOuter, endAngle);
  const ia1 = polarToCartesian(cx, cy, rInner, endAngle);
  const ia2 = polarToCartesian(cx, cy, rInner, startAngle);
  const largeArc = endAngle - startAngle > Math.PI ? 1 : 0;
  return [
    "M", oa1.x, oa1.y,
    "A", rOuter, rOuter, 0, largeArc, 1, oa2.x, oa2.y,
    "L", ia1.x, ia1.y,
    "A", rInner, rInner, 0, largeArc, 0, ia2.x, ia2.y,
    "Z"
  ].join(" ");
}

function polarToCartesian(cx, cy, r, angleRad) {
  return { x: cx + r * Math.cos(angleRad), y: cy + r * Math.sin(angleRad) };
}

/* ----------------- UI helpers ------------------ */

function renderStars(rating = 0) {
  const r = Math.round(rating);
  return (
    <>
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < r ? "star on" : "star"} aria-hidden>★</span>
      ))}
      <span className="rating-value">{Number(rating || 0).toFixed(1)}</span>
    </>
  );
}

