

// src/pages/SellerProductDetails.jsx
import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { getJSON } from "../api";

/** ---------- Tiny SVG Charts ---------- **/
function PieChart({ data = [], size = 180 }) {
  const safeData = Array.isArray(data) ? data : [];
  const total = safeData.reduce((s, d) => s + (Number(d.count) || 0), 0) || 1;
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 6;
  let angle = -Math.PI / 2;
  const palette = ["#60a5fa", "#34d399", "#fbbf24", "#f472b6", "#a78bfa", "#f87171", "#22d3ee", "#eab308"];

  const slices = safeData.map((d, i) => {
    const count = Number(d.count) || 0;
    const frac = count / total;
    const arc = frac * 2 * Math.PI;
    const x1 = cx + r * Math.cos(angle);
    const y1 = cy + r * Math.sin(angle);
    const x2 = cx + r * Math.cos(angle + arc);
    const y2 = cy + r * Math.sin(angle + arc);
    const large = arc > Math.PI ? 1 : 0;
    const path = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`;
    angle += arc;
    return { path, color: palette[i % palette.length], label: d.label, value: count };
  });

  return (
    <svg width={size + 180} height={size} viewBox={`0 0 ${size + 180} ${size}`}>
      {slices.map((s, i) => (
        <path key={i} d={s.path} fill={s.color} opacity="0.9" />
      ))}
      <g transform={`translate(${size + 12}, 10)`}>
        {slices.map((s, i) => (
          <g key={i} transform={`translate(0, ${i * 18})`}>
            <rect width="12" height="12" fill={s.color} />
            <text x="18" y="11" fill="#fff" fontSize="12">
              {String(s.label || "—")} ({s.value})
            </text>
          </g>
        ))}
      </g>
    </svg>
  );
}

function LineChart({ seriesByDate = [], width = 680, height = 240 }) {
  const rows = Array.isArray(seriesByDate) ? seriesByDate : [];
  const padding = { l: 40, r: 8, t: 10, b: 22 };
  const dates = rows.map((d) => String(d.date || ""));
  const parseX = (i) => padding.l + (i * (width - padding.l - padding.r)) / Math.max(1, dates.length - 1);
  const maxY = Math.max(1, ...rows.flatMap((d) => [d.positive || 0, d.neutral || 0, d.negative || 0]));
  const scaleY = (v) => height - padding.b - (Number(v) * (height - padding.t - padding.b)) / maxY;

  const mkPath = (key) => {
    const pts = rows.map((d, i) => [parseX(i), scaleY(Number(d[key] || 0))]);
    return pts.map((p, i) => (i === 0 ? `M ${p[0]} ${p[1]}` : `L ${p[0]} ${p[1]}`)).join(" ");
  };

  return (
    <svg width={width} height={height}>
      <line x1={padding.l} y1={height - padding.b} x2={width - padding.r} y2={height - padding.b} stroke="#666" />
      <line x1={padding.l} y1={padding.t} x2={padding.l} y2={height - padding.b} stroke="#666" />
      <text x={padding.l} y={padding.t} fill="#aaa" fontSize="12">
        count
      </text>

      <path d={mkPath("positive")} stroke="#34d399" fill="none" strokeWidth="2" />
      <path d={mkPath("neutral")} stroke="#fbbf24" fill="none" strokeWidth="2" />
      <path d={mkPath("negative")} stroke="#f87171" fill="none" strokeWidth="2" />

      {dates.map((d, i) => (
        <text key={`${d}-${i}`} x={parseX(i)} y={height - 6} fill="#aaa" fontSize="10" textAnchor="middle">
          {dates.length > 12 ? (i % Math.ceil(dates.length / 12) === 0 ? d.slice(5) : "") : d.slice(5)}
        </text>
      ))}
      <g transform="translate(70,12)">
        <circle cx="0" cy="0" r="4" fill="#34d399" />
        <text x="8" y="4" fill="#fff" fontSize="12">
          positive
        </text>
        <g transform="translate(90,0)">
          <circle cx="0" cy="0" r="4" fill="#fbbf24" />
          <text x="8" y="4" fill="#fff" fontSize="12">
            neutral
          </text>
        </g>
        <g transform="translate(170,0)">
          <circle cx="0" cy="0" r="4" fill="#f87171" />
          <text x="8" y="4" fill="#fff" fontSize="12">
            negative
          </text>
        </g>
      </g>
    </svg>
  );
}

function BarChart({ data = [], width = 980, height = 320 }) {
  const rows = Array.isArray(data) ? data : [];
  const padding = { l: 140, r: 10, t: 10, b: 10 };
  const innerH = height - padding.t - padding.b;
  const rowH = Math.max(20, Math.min(38, Math.floor(innerH / Math.max(1, rows.length))));
  const totalH = padding.t + padding.b + rowH * rows.length;
  const max = Math.max(1, ...rows.map((d) => Number(d.count) || 0));
  const scaleX = (v) => (Number(v) * (width - padding.l - padding.r)) / max;

  return (
    <svg width={width} height={totalH}>
      {rows.map((d, i) => {
        const y = padding.t + rowH * i + 5;
        const w = scaleX(Number(d.count) || 0);
        return (
          <g key={`${d.label}-${i}`}>
            <text x={12} y={y + 12} fill="#cbd5e1" fontSize="12">
              {String(d.label || "—")}
            </text>
            <rect x={padding.l} y={y} width={w} height={rowH - 10} fill="#60a5fa" opacity="0.9" rx="6" />
            <text x={padding.l + w + 6} y={y + 12} fill="#fff" fontSize="12">
              {Number(d.count) || 0}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

/** ---------- Page ---------- **/
export default function SellerProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [insights, setInsights] = useState(null);
  const [product, setProduct] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const [p, data] = await Promise.all([
          getJSON(`/products/by-id/${id}`),
          getJSON(`/seller/product/${id}/insights`),
        ]);
        if (!cancelled) {
          setProduct(p || null);
          setInsights(data || {});
        }
      } catch (e) {
        console.error("SellerProductDetails load failed:", e);
        if (!cancelled) setError(e?.message || "Failed to load product insights.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [id]);

  const title = useMemo(
    () => product?.product_title || product?.external_id || `Product #${id}`,
    [product, id]
  );

  // Normalize sentiment
  const sentimentData = useMemo(() => {
    const src = Array.isArray(insights?.sentiment_distribution) ? insights.sentiment_distribution : [];
    return src
      .map((x) => ({ label: String(x.label || "").toLowerCase(), count: Number(x.count || 0) }))
      .filter((x) => x.count > 0)
      .map((x) => ({
        label: x.label.includes("pos") ? "Positive" : x.label.includes("neg") ? "Negative" : "Neutral",
        count: x.count,
      }));
  }, [insights]);

  const trendByDate = useMemo(() => {
    const points = Array.isArray(insights?.trend_points) ? insights.trend_points : [];
    const rows = {};
    points.forEach((pt) => {
      const d = String(pt.date || "unknown");
      const s = String(pt.sentiment || "").toLowerCase();
      const key = s.includes("pos") ? "positive" : s.includes("neg") ? "negative" : "neutral";
      rows[d] = rows[d] || { date: d, positive: 0, neutral: 0, negative: 0 };
      rows[d][key] = (rows[d][key] || 0) + Number(pt.count || 0);
    });
    return Object.values(rows).sort((a, b) => String(a.date).localeCompare(String(b.date)));
  }, [insights]);

  const topComplaints = useMemo(() => {
    const src = Array.isArray(insights?.key_issues) ? insights.key_issues : [];
    return src.map((x) => ({ label: String(x.label || "—"), count: Number(x.count || 0) })).slice(0, 10);
  }, [insights]);

  const pros = useMemo(() => {
    const src = Array.isArray(insights?.pros_top) ? insights.pros_top : [];
    return src.map((x) => `${x.label} (${x.count})`).join(", ");
  }, [insights]);

  const cons = useMemo(() => {
    const src = Array.isArray(insights?.cons_top) ? insights.cons_top : [];
    return src.map((x) => `${x.label} (${x.count})`).join(", ");
  }, [insights]);

  return (
    <div>
      <Header />
      <main className="container spd-container">
        {/* Styles */}
        <style>{`
          :root {
            --bg:#0b1020; --bg2:#0e1630; --text:#e5e7eb; --muted:#9fb0d1;
            --card:#0f172a; --cardBorder:#1f2937; --primary:#3b82f6; --primary-600:#2563eb;
            --success:#34d399; --warn:#f59e0b; --danger:#ef4444;
          }
          .spd-container {
            padding: 24px; color: var(--text);
            background: radial-gradient(1200px 800px at 20% -10%, var(--bg2), var(--bg));
          }
          .btn {
            display:inline-flex; align-items:center; justify-content:center;
            height:34px; padding:0 14px; border-radius:10px;
            border:1px solid #2a3b65; background:#16223e; color:var(--text);
            cursor:pointer; transition: background .12s, border-color .12s, transform .08s;
          }
          .btn:hover { background:#1a2a52; border-color:#3a56a3; }
          .btn.ghost { background: transparent; }

          .spd-card {
            background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
            border:1px solid var(--cardBorder);
            border-radius:12px; padding:16px; box-shadow:0 1px 3px rgba(0,0,0,.25);
            margin: 14px 0;
          }
          .spd-title {
            margin: 8px 0 10px; font-size: 1.6rem; letter-spacing: -0.2px;
          }

          /* Header grid */
          .hdr-grid { display:grid; grid-template-columns: 1.05fr 1fr; gap:16px; }
          @media (max-width: 960px) { .hdr-grid { grid-template-columns: 1fr; } }
          .hdr-media {
            height: 360px; display:grid; place-items:center;
            background:#0b1222; border-radius:12px; overflow:hidden;
          }
          .hdr-media img { width:100%; height:100%; object-fit:contain; }
          .hdr-kv { display:grid; grid-template-columns: 140px 1fr; gap:8px; }
          .hdr-kv p { margin:0; }
          .hdr-kv .muted strong { color: #cbd7f5; }

          /* Overview rows */
          .row-grid { display:grid; grid-template-columns: 240px 1fr 260px; gap:10px; align-items:start; }
          @media (max-width: 960px) { .row-grid { grid-template-columns: 1fr; } }
          .row-title { font-weight:700; }
          .row-why { color: var(--muted); }

          .badges { display:flex; flex-wrap:wrap; gap:8px; }
          .badge {
            display:inline-flex; align-items:center; gap:6px;
            background: rgba(255,255,255,0.03); border:1px solid var(--cardBorder);
            border-radius:999px; padding:6px 10px; font-size:.95rem;
          }
          .dot { width:8px; height:8px; border-radius:50%; display:inline-block; }
          .dot-pos { background:#22c55e; } .dot-neg { background:#ef4444; } .dot-neu { background:#eab308; }

          /* Charts grid */
          .charts-grid { display:grid; grid-template-columns: 1fr 1fr; gap:16px; }
          @media (max-width: 1000px) { .charts-grid { grid-template-columns: 1fr; } }
          .chart-card { background: rgba(255,255,255,0.02); border:1px solid var(--cardBorder); border-radius:12px; padding:12px; }
          .chart-title { margin: 0 0 8px; font-size:1.1rem; letter-spacing: -.1px; }
        `}</style>

        {/* Top actions */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button className="btn ghost" onClick={() => navigate(-1)}>&larr; Back</button>
          <Link to="/seller" className="btn ghost">Seller Home</Link>
        </div>

        {/* Product title */}
        <h2 className="spd-title">{title}</h2>

        {/* Header: image + meta */}
        <section className="spd-card">
          {!product ? (
            <p className="muted">Loading product…</p>
          ) : (
            <div className="hdr-grid">
              <div className="hdr-media">
                <img
                  alt={title}
                  src={product?.image_url || "https://via.placeholder.com/800x600?text=Product"}
                  onError={(e) => { e.currentTarget.src = "https://via.placeholder.com/800x600?text=No+Image"; }}
                />
              </div>
              <div>
                <div className="hdr-kv">
                  <p className="muted"><strong>Brand:</strong></p><p>{product?.brand || "—"}</p>
                  <p className="muted"><strong>Category:</strong></p><p>{product?.category || "—"}</p>
                  <p className="muted"><strong>Subtype:</strong></p><p>{product?.subtype || "—"}</p>
                  <p className="muted"><strong>SKU:</strong></p><p>{product?.sku || "—"}</p>
                  <p className="muted"><strong>External ID:</strong></p><p>{product?.external_id || "—"}</p>
                  <p className="muted"><strong>Source:</strong></p><p>{product?.source || "—"}</p>
                  <p className="muted"><strong>Price:</strong></p>
                  <p>{product?.price != null ? `₹${Number(product.price).toFixed(2)}` : "—"}</p>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Insights overview */}
        <section className="spd-card">
          <h3 style={{ margin: "0 0 10px" }}>Insights</h3>
          {loading && <p className="muted">Loading insights…</p>}
          {error && <p style={{ color: "#f66" }}>{error}</p>}

          {!loading && !error && insights && (
            <div className="row-grid">
              {/* Pros */}
              <div className="row-title">Pros (aggregated)</div>
              <div>
                <div className="badges">
                  {Array.isArray(insights.pros_top) && insights.pros_top.length ? (
                    insights.pros_top.map((x, i) => (
                      <span key={`pro-${i}`} className="badge">
                        <span className="dot dot-pos" />
                        {String(x.label || "—")} <span className="muted">({Number(x.count) || 0})</span>
                      </span>
                    ))
                  ) : (
                    <span className="muted">—</span>
                  )}
                </div>
              </div>
              <div className="row-why">What to highlight in product listing</div>

              {/* Cons */}
              <div className="row-title">Cons (aggregated)</div>
              <div>
                <div className="badges">
                  {Array.isArray(insights.cons_top) && insights.cons_top.length ? (
                    insights.cons_top.map((x, i) => (
                      <span key={`con-${i}`} className="badge">
                        <span className="dot dot-neg" />
                        {String(x.label || "—")} <span className="muted">({Number(x.count) || 0})</span>
                      </span>
                    ))
                  ) : (
                    <span className="muted">—</span>
                  )}
                </div>
              </div>
              <div className="row-why">What needs fixing</div>

              {/* Sentiment */}
              <div className="row-title">Sentiment distribution</div>
              <div>
                <div className="badges">
                  {Array.isArray(insights.sentiment_distribution) && insights.sentiment_distribution.length ? (
                    insights.sentiment_distribution.map((x, i) => (
                      <span key={`sent-${i}`} className="badge">
                        <span
                          className={`dot ${
                            String(x.label || "").toLowerCase().includes("pos")
                              ? "dot-pos"
                              : String(x.label || "").toLowerCase().includes("neg")
                              ? "dot-neg"
                              : "dot-neu"
                          }`}
                        />
                        {String(x.label || "—")}: <strong style={{ marginLeft: 4 }}>{Number(x.count) || 0}</strong>
                      </span>
                    ))
                  ) : (
                    <span className="muted">—</span>
                  )}
                </div>
              </div>
              <div className="row-why">Health of the product</div>

              {/* Trend */}
              <div className="row-title">Trend over time</div>
              <div>
                <p className="muted" style={{ margin: 0 }}>
                  {Array.isArray(insights.trend_points) && insights.trend_points.length ? "See charts below" : "—"}
                </p>
              </div>
              <div className="row-why">Detect quality degradation</div>

              {/* Top complaints */}
              <div className="row-title">Top complaints</div>
              <div>
                <div className="badges">
                  {Array.isArray(insights.key_issues) && insights.key_issues.length ? (
                    insights.key_issues.map((x, i) => (
                      <span key={`issue-${i}`} className="badge">
                        ⚠️ {String(x.label || "—")} <span className="muted">({Number(x.count) || 0})</span>
                      </span>
                    ))
                  ) : (
                    <span className="muted">—</span>
                  )}
                </div>
              </div>
              <div className="row-why">Root-cause analysis</div>
            </div>
          )}
        </section>

        {/* Charts */}
        <section className="charts-grid">
          <div className="chart-card">
            <h4 className="chart-title">Sentiment distribution</h4>
            {sentimentData.length ? (
              <PieChart data={sentimentData} size={220} />
            ) : (
              <p className="muted">No sentiment data.</p>
            )}
          </div>

          <div className="chart-card">
            <h4 className="chart-title">Trend over time</h4>
            {trendByDate.length ? (
              <LineChart seriesByDate={trendByDate} width={680} height={240} />
            ) : (
              <p className="muted">No trend data.</p>
            )}
          </div>
        </section>

        <section className="spd-card">
          <h4 style={{ margin: "0 0 8px" }}>Top complaints</h4>
          {topComplaints.length ? <BarChart data={topComplaints} /> : <p className="muted">No complaint data.</p>}
        </section>
      </main>
    </div>
  );
}
