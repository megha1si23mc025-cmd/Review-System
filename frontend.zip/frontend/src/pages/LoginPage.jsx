
// src/pages/LoginPage.jsx
import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../styles/register.css";
import Header from "../components/Header";
import { useAuth } from "../auth/AuthContext";
import { postJSON } from "../api";

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, loginWithToken, refreshMe } = useAuth();

  const [flashMsg, setFlashMsg] = useState(null);
  useEffect(() => {
    const msg = location.state && location.state.flash;
    if (msg) {
      setFlashMsg(msg);
      navigate(location.pathname, { replace: true });
    }
  }, [location, navigate]);

  const initialTab = new URLSearchParams(location.search).get("tab") || "buyer";
  const [tab, setTab] = useState(initialTab); // buyer | seller-password | seller-otp | admin | support

  const [buyerForm, setBuyerForm] = useState({ email: "", password: "" });
  const [sellerPwForm, setSellerPwForm] = useState({ email: "", password: "" });
  const [sellerOtpForm, setSellerOtpForm] = useState({ email: "", otp: "" });
  const [adminForm, setAdminForm] = useState({ email: "", password: "" });
  const [supportForm, setSupportForm] = useState({ email: "", password: "" });

  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  function roleToPath(role) {
    if (role === "buyer") return "/customer";
    if (role === "seller") return "/seller";
    if (role === "support") return "/support";
    if (role === "admin") return "/manager";
    return "/";
  }

  function onChange(setter) {
    return (e) => {
      const { name, value } = e.target;
      setter((p) => ({ ...p, [name]: value }));
      setErrors((prev) => { const next = { ...prev }; delete next[name]; delete next.submit; return next; });
    };
  }

  async function safeNavigateByRole(me) {
    let profile = me;
    if (!profile) {
      profile = await refreshMe();
    }
    if (!profile || !profile.role) {
      setErrors((prev) => ({ ...prev, submit: "Login succeeded, but profile could not be loaded. Please try again." }));
      return;
    }
    navigate(roleToPath(profile.role), { replace: true });
  }

  async function onSubmit(e, form) {
    e.preventDefault();
    if (!form.email?.trim() || !form.password) {
      setErrors((prev) => ({ ...prev, submit: "Email and password are required." }));
      return;
    }
    setSubmitting(true);
    try {
      const me = await login(form.email.trim(), form.password);
      await safeNavigateByRole(me);
    } catch (err) {
      setErrors((prev) => ({ ...prev, submit: err?.message || "Login failed." }));
    } finally {
      setSubmitting(false);
    }
  }

  async function onSubmitSellerOTP(e) {
    e.preventDefault();
    if (!sellerOtpForm.email.trim() || !sellerOtpForm.otp.trim()) {
      setErrors((prev) => ({ ...prev, submit: "Email and OTP are required." }));
      return;
    }
    setSubmitting(true);
    try {
      const res = await postJSON("/auth/seller/otp/verify", {
        email: sellerOtpForm.email.trim(),
        otp: sellerOtpForm.otp.trim(),
      });
      const me = await loginWithToken(res.access_token);
      await safeNavigateByRole(me);
    } catch (err) {
      setErrors((prev) => ({ ...prev, submit: err?.message || "OTP verification failed." }));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="register-v10">
      <Header />
      <div className="register-v10__container">
        <div className="inner glass card" style={{ width: "min(560px, 92vw)" }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            <button onClick={() => setTab("buyer")} className="btn ghost">Buyer Login</button>
            <button onClick={() => setTab("seller-password")} className="btn ghost">Seller – Password</button>
            <button onClick={() => setTab("seller-otp")} className="btn ghost">Seller – First-time OTP</button>
            <button onClick={() => setTab("support")} className="btn ghost">Support Login</button>
            <button onClick={() => setTab("admin")} className="btn ghost">Admin Login</button>
          </div>

          {flashMsg && (
            <div className="submit-success" role="status" style={{ background: "rgba(0, 200, 120, 0.2)", color: "#b6ffcc", padding: "10px 12px", borderRadius: 8, marginBottom: 12 }}>
              {flashMsg}
            </div>
          )}

          {tab === "buyer" && (
            <form onSubmit={(e) => onSubmit(e, buyerForm)} noValidate>
              <h3 className="register-title">Buyer Login</h3>
              <div className="form-holder">
                <input type="email" className="form-control" placeholder="Email" name="email"
                  value={buyerForm.email} onChange={onChange(setBuyerForm)} autoComplete="username" />
              </div>
              <div className="form-holder">
                <input type="password" className="form-control" placeholder="Password" name="password"
                  value={buyerForm.password} onChange={onChange(setBuyerForm)} autoComplete="current-password" />
              </div>
              <button type="submit" className="btn primary" disabled={submitting}>
                <span>{submitting ? "Signing in..." : "Login"}</span>
              </button>
              {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
            </form>
          )}

          {tab === "seller-password" && (
            <form onSubmit={(e) => onSubmit(e, sellerPwForm)} noValidate>
              <h3 className="register-title">Seller Login (Password)</h3>
              <div className="form-holder">
                <input type="email" className="form-control" placeholder="Email" name="email"
                  value={sellerPwForm.email} onChange={onChange(setSellerPwForm)} />
              </div>
              <div className="form-holder">
                <input type="password" className="form-control" placeholder="Password" name="password"
                  value={sellerPwForm.password} onChange={onChange(setSellerPwForm)} />
              </div>
              <button type="submit" className="btn primary" disabled={submitting}>
                <span>{submitting ? "Signing in..." : "Login"}</span>
              </button>
              {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
            </form>
          )}

          {tab === "seller-otp" && (
            <form onSubmit={onSubmitSellerOTP} noValidate>
              <h3 className="register-title">Seller First‑time Login (OTP)</h3>
              <p className="hint">
                OTP is emailed when admin approves your application. If you didn’t receive it or it expired, ask admin to resend.
              </p>
              <div className="form-holder">
                <input type="email" className="form-control" placeholder="Email" name="email"
                  value={sellerOtpForm.email} onChange={onChange(setSellerOtpForm)} />
              </div>
              <div className="form-holder">
                <input type="text" className="form-control" placeholder="OTP" name="otp"
                  value={sellerOtpForm.otp} onChange={onChange(setSellerOtpForm)} />
              </div>
              <button type="submit" className="btn primary" disabled={submitting}>
                <span>{submitting ? "Verifying..." : "Verify OTP"}</span>
              </button>
              {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
            </form>
          )}

          {tab === "support" && (
            <form onSubmit={(e) => onSubmit(e, supportForm)} noValidate>
              <h3 className="register-title">Customer Support Login</h3>
              <div className="form-holder">
                <input type="email" className="form-control" placeholder="Support Email" name="email"
                  value={supportForm.email} onChange={onChange(setSupportForm)} />
              </div>
              <div className="form-holder">
                <input type="password" className="form-control" placeholder="Password" name="password"
                  value={supportForm.password} onChange={onChange(setSupportForm)} />
              </div>
              <button type="submit" className="btn primary" disabled={submitting}>
                <span>{submitting ? "Signing in..." : "Login"}</span>
              </button>
              {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
            </form>
          )}

          {tab === "admin" && (
            <form onSubmit={(e) => onSubmit(e, adminForm)} noValidate>
              <h3 className="register-title">Admin Login</h3>
              <div className="form-holder">
                <input type="email" className="form-control" placeholder="Admin Email" name="email"
                  value={adminForm.email} onChange={onChange(setAdminForm)} />
              </div>
              <div className="form-holder">
                <input type="password" className="form-control" placeholder="Admin Password" name="password"
                  value={adminForm.password} onChange={onChange(setAdminForm)} />
              </div>
              <button type="submit" className="btn primary" disabled={submitting}>
                <span>{submitting ? "Signing in..." : "Login"}</span>
              </button>
              {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
