
// src/pages/Seller.jsx
import { useEffect, useMemo, useState } from "react";
import Header from "../components/Header";
import { getJSON, postJSON } from "../api";
import { useAuth } from "../auth/AuthContext";

export default function Seller() {
  const { user, refreshMe } = useAuth();
  const [mustChangePw, setMustChangePw] = useState(!!user?.must_change_password);

  // Support team state
  const [teams, setTeams] = useState([]);
  const [myTeam, setMyTeam] = useState(null);
  const [teamPicking, setTeamPicking] = useState(false);
  const [flash, setFlash] = useState("");

  // Products + insights
  const [products, setProducts] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [insights, setInsights] = useState(null);

  // UI: product search
  const [prodQuery, setProdQuery] = useState("");

  useEffect(() => {
    (async () => {
      const me = user || (await refreshMe());
      setMustChangePw(!!me?.must_change_password);

      // my products
      try {
        const rows = await getJSON("/seller/me/products");
        setProducts(rows || []);
        if (!selectedId && rows?.length) setSelectedId(rows[0].id);
      } catch (_) {}

      // my team (if any)
      try {
        const res = await getJSON("/support/seller/my-support-team");
        setMyTeam(res?.team || null);
        if (!res?.team) {
          const list = await getJSON("/support/teams");
          setTeams(list || []);
        }
      } catch (_) {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    (async () => {
      try {
        const data = await getJSON(`/seller/product/${selectedId}/insights`);
        setInsights(data);
      } catch (e) {
        setInsights(null);
      }
    })();
  }, [selectedId]);

  async function chooseTeam(teamId) {
    setTeamPicking(true);
    setFlash("");
    try {
      const res = await postJSON(
        `/support/seller/choose-support-team?team_id=${teamId}`,
        {}
      );
      if (res.status === "ok" || res.status === "exists") {
        const cur = await getJSON("/support/seller/my-support-team");
        setMyTeam(cur?.team || null);
      } else {
        setFlash("Could not set team.");
      }
    } catch (e) {
      setFlash(e?.message || "Failed to set team.");
    } finally {
      setTeamPicking(false);
    }
  }

  const filteredProducts = useMemo(() => {
    const q = prodQuery.trim().toLowerCase();
    if (!q) return products || [];
    return (products || []).filter((p) =>
      (p.product_title || `#${p.id}` || "")
        .toString()
        .toLowerCase()
        .includes(q)
    );
  }, [products, prodQuery]);

  return (
    <div>
      <Header />
      <div className="seller-container">
        {/* Scoped Styles */}
        <style>{`
          :root{
            --bg: #0b1020;
            --bg2:#0e1630;
            --text:#e5e7eb;
            --muted:#9fb0d1;
            --card:#0f172a;
            --cardBorder:#1f2937;
            --primary:#3b82f6;
            --primary-600:#2563eb;
            --success:#34d399;
            --warn:#f59e0b;
            --chip:#16223e;
            --chipBorder:#2a3b65;
          }

          .seller-container{
            width:100%;
            max-width:1200px;
            margin:0 auto;
            padding:24px;
            color:var(--text);
          }

          .grid{
            display:grid;
            gap:16px;
          }

          .card{
            background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
            border:1px solid var(--cardBorder);
            border-radius:12px;
            box-shadow:0 1px 3px rgba(0,0,0,.25);
            padding:14px 16px;
          }

          .card h3, .card h4{
            margin:0 0 8px;
            letter-spacing:-0.2px;
          }

          .muted{ color: var(--muted); }
          .hint{ color: var(--muted); margin: 6px 0 0; }

          .btn{
            display:inline-flex; align-items:center; justify-content:center;
            height:34px; padding:0 14px; border-radius:10px;
            border:1px solid var(--chipBorder); background: var(--chip);
            color: var(--text); cursor:pointer; user-select:none;
            transition: background .12s ease, border-color .12s ease, transform .08s ease;
          }
          .btn:hover{ background:#1a2a52; border-color:#3a56a3; }
          .btn:active{ transform: translateY(1px); }
          .btn.ghost{ background: transparent; }
          .btn.primary{ background: var(--primary); border-color: var(--primary-600); color: #fff; }
          .btn.primary:hover{ background: var(--primary-600); }

          /* Team strip */
          .team-strip{
            display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;
          }
          .team-pills{ display:flex; gap:8px; flex-wrap:wrap; }
          .pill{
            height:32px; padding:0 12px; border-radius:999px;
            border:1px solid var(--chipBorder); background: var(--chip);
          }

          /* Products */
          .products-header{
            display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;
            margin-bottom:8px;
          }
          .search{
            flex:1 1 280px;
            display:flex; align-items:center; gap:8px;
            background: var(--card); border:1px solid var(--cardBorder);
            border-radius:10px; padding:6px 10px;
          }
          .search input{
            flex:1; background:transparent; border:none; color:var(--text); outline:none;
          }
          .chips-wrap{
            display:flex; gap:8px; flex-wrap:wrap;
            max-height: 132px; overflow:auto; padding-right:4px; margin-top:6px;
          }
          .chip{
            display:inline-flex; align-items:center; gap:6px; max-width:100%;
            background: var(--chip);
            border:1px solid var(--chipBorder);
            color: var(--text);
            padding:6px 10px; border-radius:999px; cursor:pointer; white-space:nowrap;
            transition: background .12s ease, border-color .12s ease;
          }
          .chip:hover{ background:#1a2a52; border-color:#3a56a3; }
          .chip.active{ border-color:#7c6cff; box-shadow: 0 0 0 2px rgba(124,108,255,.22) inset; }

          /* Insights grid (titles / values / help) */
          .row-grid{
            display:grid; gap:10px; align-items:start;
            grid-template-columns: 240px 1fr 260px;
          }
          @media (max-width: 820px){
            .row-grid{ grid-template-columns: 1fr; }
          }
          .row{ display: contents; } /* maintain your layout */
          .row-title{ font-weight:700; }
          .row-why{ color: var(--muted); }

          /* NEW: subsection container to visually separate Pros/Cons/etc. */
          .subcard {
            border: 1px dashed rgba(255,255,255,0.12);
            border-radius: 10px;
            padding: 10px 12px;
            margin: 6px 0;
            background: rgba(255,255,255,0.02);
          }
          .subcard h5 {
            margin: 0 0 8px;
            font-size: 1rem;
            letter-spacing: -0.1px;
          }
          .sub-sep { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 0; }

          .badges{ display:flex; flex-wrap:wrap; gap:6px; }
          .badge{
            display:inline-flex; align-items:center; gap:6px;
            background: rgba(255,255,255,0.03);
            border:1px solid var(--cardBorder);
            border-radius:8px;
            padding:4px 8px;
            font-size:.95rem;
          }
          .badge .dot{ width:8px; height:8px; border-radius:50%; display:inline-block; }
          .dot-pos { background: #22c55e; }
          .dot-neg { background: #ef4444; }
          .dot-neu { background: #eab308; }

          /* Scrollbars (subtle) */
          .chips-wrap::-webkit-scrollbar{ height: 8px; width:8px; }
          .chips-wrap::-webkit-scrollbar-thumb{ background:#1f2b4a; border-radius:8px; }
        `}</style>

        {/* ===== Support Team ===== */}
        <section className="card">
          {!myTeam ? (
            <div className="team-strip">
              <div>
                <h4 style={{ margin: 0 }}>Choose your Customer Support team</h4>
                <p className="muted" style={{ margin: "4px 0 0" }}>
                  Pick one team to route your customer issues.
                </p>
              </div>
              <div className="team-pills">
                {(teams || []).map((t) => (
                  <button
                    key={t.id}
                    className="pill btn"
                    disabled={teamPicking}
                    onClick={() => chooseTeam(t.id)}
                    title={`Assign ${t.name}`}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="team-strip">
              <div>
                <h4 style={{ margin: 0 }}>Your support team</h4>
                <p className="muted" style={{ margin: "4px 0 0" }}>
                  Assigned to: <strong>{myTeam.name}</strong>
                </p>
              </div>
            </div>
          )}
          {flash && <div className="hint" style={{ marginTop: 8, color: "#ffd7d7" }}>{flash}</div>}
        </section>

        {/* ===== My Products ===== */}
        <section className="card">
          <div className="products-header">
            <h3 style={{ margin: 0 }}>My Products</h3>
            <div className="search" role="search">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                <line x1="16.65" y1="16.65" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              <input
                value={prodQuery}
                onChange={(e) => setProdQuery(e.target.value)}
                placeholder="Search your products…"
                aria-label="Search products"
              />
            </div>
          </div>

          <div className="chips-wrap" aria-label="Your products">
            {(filteredProducts || []).map((p) => (
              <button
                key={p.id}
                className={`chip ${selectedId === p.id ? "active" : ""}`}
                onClick={() => setSelectedId(p.id)}
                title={p.product_title}
              >
                <span style={{ opacity: 0.8 }}>#{p.id}</span>
                <span style={{ maxWidth: 420, overflow: "hidden", textOverflow: "ellipsis" }}>
                  {p.product_title}
                </span>
              </button>
            ))}
          </div>

          {!products?.length && <p className="hint">No products yet.</p>}
          {!!products?.length && filteredProducts.length === 0 && (
            <p className="hint">No matches for “{prodQuery}”.</p>
          )}
        </section>

        {/* ===== Insights (SEPARATED subsections) ===== */}
        <section className="card">
          <h3 style={{ marginBottom: 6 }}>Product insights</h3>
          {!selectedId && <p className="hint">Select a product to see insights.</p>}
          {selectedId && !insights && <p className="hint">Loading…</p>}

          {selectedId && insights && (
            <>
              {/* Pros block */}
              <div className="subcard" aria-label="Pros (aggregated)">
                <h5>Pros (aggregated)</h5>
                <div className="badges">
                  {(insights.pros_top || []).length
                    ? (insights.pros_top || []).map((x, i) => (
                        <span key={`pro-${i}`} className="badge">
                          <span className="dot dot-pos" />
                          {x.label}
                          <span className="muted">({x.count})</span>
                        </span>
                      ))
                    : <span className="muted">—</span>}
                </div>
                <div className="sub-sep" />
                <p className="muted">What to highlight in product listing</p>
              </div>

              {/* Cons block */}
              <div className="subcard" aria-label="Cons (aggregated)">
                <h5>Cons (aggregated)</h5>
                <div className="badges">
                  {(insights.cons_top || []).length
                    ? (insights.cons_top || []).map((x, i) => (
                        <span key={`con-${i}`} className="badge">
                          <span className="dot dot-neg" />
                          {x.label}
                          <span className="muted">({x.count})</span>
                        </span>
                      ))
                    : <span className="muted">—</span>}
                </div>
                <div className="sub-sep" />
                <p className="muted">What needs fixing</p>
              </div>

              {/* Sentiment block */}
              <div className="subcard" aria-label="Sentiment distribution">
                <h5>Sentiment distribution</h5>
                <div className="badges">
                  {(insights.sentiment_distribution || []).length
                    ? (insights.sentiment_distribution || []).map((x, i) => (
                        <span key={`sent-${i}`} className="badge">
                          <span className={`dot ${
                            x.label?.toLowerCase().includes("pos") ? "dot-pos" :
                            x.label?.toLowerCase().includes("neg") ? "dot-neg" : "dot-neu"
                          }`} />
                          {x.label}: <strong style={{ marginLeft: 4 }}>{x.count}</strong>
                        </span>
                      ))
                    : <span className="muted">—</span>}
                </div>
                <div className="sub-sep" />
                <p className="muted">Health of the product</p>
              </div>

              {/* Trend block */}
              <div className="subcard" aria-label="Trend over time">
                <h5>Trend over time</h5>
                <p className="muted" style={{ margin: 0 }}>
                  {(insights.trend_points || [])
                    .slice(-8)
                    .map((x) => `${x.date} ${x.sentiment}:${x.count}`)
                    .join(" | ") || "—"}
                </p>
                <div className="sub-sep" />
                <p className="muted">Detect quality degradation</p>
              </div>

              {/* Top complaints block */}
              <div className="subcard" aria-label="Top complaints">
                <h5>Top complaints</h5>
                <div className="badges">
                  {(insights.key_issues || []).length
                    ? (insights.key_issues || []).map((x, i) => (
                        <span key={`issue-${i}`} className="badge">
                          ⚠️ {x.label}
                          <span className="muted">({x.count})</span>
                        </span>
                      ))
                    : <span className="muted">—</span>}
                </div>
                <div className="sub-sep" />
                <p className="muted">Root-cause analysis</p>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
