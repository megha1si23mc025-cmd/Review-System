
# backend/app/core/security.py
import os
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple
import hashlib, hmac, secrets, base64
from jose import jwt  # pip install "python-jose[cryptography]"

# ---- Password Hashing (PBKDF2-SHA256) ----
ALGO = "pbkdf2_sha256"
ITERATIONS = 200_000
KEYLEN = 32

def hash_password(plain: str) -> str:
    if not isinstance(plain, str) or plain == "":
        raise ValueError("Password required")
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, ITERATIONS, dklen=KEYLEN)
    return f"{ALGO}${ITERATIONS}${base64.b16encode(salt).decode()}${base64.b16encode(dk).decode()}"

def verify_password(plain: str, stored: str) -> bool:
    try:
        algo, iters_s, salt_hex, hash_hex = stored.split("$", 3)
        if algo != ALGO:
            return False
        iters = int(iters_s)
        salt = base64.b16decode(salt_hex.encode())
        expected = base64.b16decode(hash_hex.encode())
        test = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, iters, dklen=len(expected))
        return hmac.compare_digest(test, expected)
    except Exception:
        return False

def generate_temp_password(length: int = 14) -> str:
    # URL-safe random string (no special chars that break forms)
    return secrets.token_urlsafe(max(10, length))[:length]

# ---- JWT ----
def create_access_token(
    subject: str,
    expires_minutes: int,
    secret: str,
    algorithm: str = "HS256",
    extra_claims: Optional[dict] = None,
) -> str:
    now = datetime.now(tz=timezone.utc)
    exp = now + timedelta(minutes=expires_minutes)
    payload = {"sub": subject, "iat": int(now.timestamp()), "exp": int(exp.timestamp())}
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, secret, algorithm=algorithm)

def decode_access_token(token: str, secret: str, algorithms: Tuple[str, ...]) -> dict:
    return jwt.decode(token, secret, algorithms=list(algorithms))
