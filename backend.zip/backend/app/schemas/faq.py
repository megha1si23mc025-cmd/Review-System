
# backend/app/schemas/faq.py
from pydantic import BaseModel
from typing import List, Optional

class ProductAnswerOut(BaseModel):
    id: int
    question_id: int
    answer_text: str
    answered_at: str

class ProductQuestionOut(BaseModel):
    id: int
    product_id: int
    question_text: str
    asked_at: str
    language: str
    answers: List[ProductAnswerOut]
