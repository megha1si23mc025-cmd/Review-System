
# backend/app/schemas/auth.py
from pydantic import BaseModel, EmailStr
from typing import Optional

class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    password: str
    role: str = "buyer"          # Only 'buyer' is allowed for self-register

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserMe(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    role: str
    seller_id: Optional[int] = None
    must_change_password: bool = False

# NEW: Admin creates seller users (invite-only)
class AdminCreateSellerUserRequest(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    seller_external_id: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str
