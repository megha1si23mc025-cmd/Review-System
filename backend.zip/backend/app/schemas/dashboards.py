
from pydantic import BaseModel
from typing import List

class SentimentPoint(BaseModel):
    date: str
    sentiment: str
    count: int

class SentimentTrendOut(BaseModel):
    points: List[SentimentPoint]

class ThemeCount(BaseModel):
    theme: str
    count: int

class KeyIssuesOut(BaseModel):
    themes: List[ThemeCount]
