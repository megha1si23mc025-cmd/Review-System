
from pydantic import BaseModel
from typing import List, Dict, Any

class AnalysisCreate(BaseModel):
    review_id: int
    llm_model: str = "imported/offline"
    provider: str = "offline"
    prompt_version: str = "v1"
    summary: str | None = None
    pros: List[str] | None = None
    cons: List[str] | None = None
    sentiment: str = "unknown"
    verdict: str | None = None
    key_themes: List[Dict[str, Any]] | None = None
    raw_output: Dict[str, Any] | None = None

class AnalysisOut(BaseModel):
    review_id: int
    summary: str | None = None
    pros: List[str] | None = None
    cons: List[str] | None = None
    sentiment: str
    verdict: str | None = None
    key_themes: List[Dict[str, Any]] | None = None
