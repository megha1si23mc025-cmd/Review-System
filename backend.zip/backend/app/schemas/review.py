
from pydantic import BaseModel

class ReviewCreate(BaseModel):
    product_id: int
    rating: int | None = None
    review_title: str | None = None
    review_text: str
    review_date: str
    reviewer_name: str | None = None
    verified_purchase: bool = False
    helpful_votes: int = 0
    source: str | None = "web"

class ReviewOut(BaseModel):
    id: int
    product_id: int
    rating: int | None
    review_title: str | None
    review_text: str
    review_date: str
    reviewer_name: str | None
    verified_purchase: bool
    helpful_votes: int
    source: str | None
