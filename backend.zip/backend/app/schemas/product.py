
from pydantic import BaseModel

class ProductCreate(BaseModel):
    sku: str
    product_title: str
    brand: str | None = None
    category: str = "Electronics"
    price: float | None = None
    source: str | None = None
    external_id: str | None = None
    subtype: str | None = None

class ProductOut(BaseModel):
    id: int
    sku: str
    product_title: str
    brand: str | None
    category: str
    price: float | None
    source: str | None
    external_id: str | None
    subtype: str | None
