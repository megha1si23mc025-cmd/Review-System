
from pydantic import BaseModel
from typing import List, Dict, Any

class ProductBulkItem(BaseModel):
    sku: str
    product_title: str
    brand: str | None = None
    category: str = "Electronics"
    price: float | None = None
    source: str | None = None
    external_id: str | None = None
    subtype: str | None = None

class ReviewBulkItem(BaseModel):
    product_id: int
    rating: int | None = None
    review_title: str | None = None
    review_text: str
    review_date: str
    reviewer_name: str | None = None
    verified_purchase: bool = False
    helpful_votes: int = 0
    source: str | None = "web"

class AnalysisBulkItem(BaseModel):
    review_id: int
    summary: str | None = None
    pros: List[str] | None = None
    cons: List[str] | None = None
    sentiment: str = "unknown"
    verdict: str | None = None
    key_themes: List[Dict[str, Any]] | None = None
    raw_output: Dict[str, Any] | None = None
