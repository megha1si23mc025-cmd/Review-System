
from pydantic import BaseModel

class SellerCreate(BaseModel):
    external_id: str
    name: str
    email: str | None = None

class SellerOut(BaseModel):
    id: int
    external_id: str
    name: str
    email: str | None = None
