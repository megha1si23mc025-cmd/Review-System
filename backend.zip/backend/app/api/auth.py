
# backend/app/api/auth.py
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from sqlalchemy import select
from jose import JWTError
from datetime import datetime, timedelta, timezone
from typing import Optional

from app.db.session import get_db
from app.models.user import User
from app.models.seller import Seller
from app.core.config import Settings
from app.core.security import hash_password, verify_password, create_access_token, decode_access_token
from app.schemas.auth import (
    RegisterRequest, TokenResponse, UserMe,
    ChangePasswordRequest, PasswordResetRequest, PasswordResetConfirm
)

router = APIRouter()

settings = Settings()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def _issue_token(u: User) -> str:
    return create_access_token(
        subject=str(u.id),
        expires_minutes=settings.jwt_expire_minutes,
        secret=settings.jwt_secret,
        algorithm=settings.jwt_algorithm,
        extra_claims={"role": u.role, "email": u.email, "seller_id": u.seller_id, "mcp": u.must_change_password},
    )

@router.post("/register", response_model=TokenResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    # Allow ONLY buyer self-registration
    if payload.role != "buyer":
        raise HTTPException(400, "Only buyers can self-register. Sellers are invite-only.")
    exists = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if exists:
        raise HTTPException(400, "Email already registered")
    u = User(
        email=payload.email,
        full_name=payload.full_name,
        password_hash=hash_password(payload.password),
        role="buyer",
        seller_id=None,
        must_change_password=False,
    )
    db.add(u); db.commit(); db.refresh(u)
    token = _issue_token(u)
    return TokenResponse(access_token=token)

@router.post("/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == form.username)).scalar_one_or_none()
    if not user or not verify_password(form.password, user.password_hash) or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = _issue_token(user)
    return TokenResponse(access_token=token)

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    try:
        payload = decode_access_token(token, settings.jwt_secret, (settings.jwt_algorithm,))
        uid = int(payload.get("sub"))
    except (JWTError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid token")
    user = db.get(User, uid)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Inactive user")
    return user

def require_role(*roles: str):
    def _dep(u: User = Depends(get_current_user)) -> User:
        if u.role not in roles:
            raise HTTPException(403, "Forbidden")
        return u
    return _dep

@router.get("/me", response_model=UserMe)
def me(u: User = Depends(get_current_user)):
    return UserMe(
        id=u.id, email=u.email, full_name=u.full_name, role=u.role, seller_id=u.seller_id,
        must_change_password=u.must_change_password
    )

# NEW: Change own password (for all roles)
@router.post("/change-password", response_model=dict)
def change_password(payload: ChangePasswordRequest, u: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(payload.old_password, u.password_hash):
        raise HTTPException(400, "Old password incorrect")
    u.password_hash = hash_password(payload.new_password)
    u.must_change_password = False
    db.add(u); db.commit()
    return {"status": "ok"}

# NEW: Request reset
@router.post("/request-password-reset", response_model=dict)
def request_password_reset(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    # Don't leak existence; still generate a "fake success"
    if u:
        from secrets import token_urlsafe
        u.reset_token = token_urlsafe(48)
        u.reset_expires = datetime.now(timezone.utc) + timedelta(hours=2)
        db.add(u); db.commit()
        # You would email u.reset_token to the user out-of-band
    return {"status": "ok"}  # Always ok

# NEW: Confirm reset
@router.post("/confirm-password-reset", response_model=dict)
def confirm_password_reset(payload: PasswordResetConfirm, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.reset_token == payload.token)).scalar_one_or_none()
    if not u or not u.reset_expires or u.reset_expires < datetime.now(timezone.utc):
        raise HTTPException(400, "Invalid or expired token")
    u.password_hash = hash_password(payload.new_password)
    u.reset_token = None
    u.reset_expires = None
    u.must_change_password = False
    db.add(u); db.commit()
    return {"status": "ok"}
