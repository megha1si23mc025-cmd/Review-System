
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db
from app.schemas.dashboards import SentimentTrendOut, SentimentPoint, KeyIssuesOut, ThemeCount
from datetime import datetime, date

router = APIRouter()

def _parse_date(s: str | None) -> date | None:
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            continue
    try:
        # ISO fallback (supports YYYY-MM-DD)
        return datetime.fromisoformat(s).date()
    except Exception:
        return None

@router.get("/product/{product_id}/key-issues", response_model=KeyIssuesOut)
def key_issues(product_id: int, limit: int = 20, db: Session = Depends(get_db)):
    q = """
    SELECT lower(elem->>'theme') AS theme, COUNT(*) AS cnt
    FROM analyses a
    JOIN reviews r ON r.id = a.review_id
    CROSS JOIN LATERAL jsonb_array_elements(a.key_themes) AS elem
    WHERE r.product_id = :pid
    GROUP BY theme
    ORDER BY cnt DESC
    LIMIT :limit
    """
    rows = db.execute(text(q), {"pid": product_id, "limit": limit}).all()
    return KeyIssuesOut(themes=[ThemeCount(theme=str(t[0]), count=int(t[1])) for t in rows])

@router.get("/product/{product_id}/sentiment-trend", response_model=SentimentTrendOut)
def sentiment_trend(product_id: int, start: str | None = None, end: str | None = None, db: Session = Depends(get_db)):
    start_dt = _parse_date(start)
    end_dt   = _parse_date(end)

    # Build WHERE clause
    where = ["product_id = :pid"]
    params = {"pid": product_id}
    if start_dt:
        where.append("day >= :start")
        params["start"] = start_dt
    if end_dt:
        where.append("day <= :end")
        params["end"] = end_dt

    q = f"""
    SELECT day, sentiment, count
    FROM mv_product_sentiment_daily
    WHERE {' AND '.join(where)}
    ORDER BY day, sentiment
    """

    try:
        rows = db.execute(text(q), params).all()
        points = [SentimentPoint(date=str(r[0]), sentiment=str(r[1]), count=int(r[2])) for r in rows]
    except Exception:
        # MV might not exist yet; return empty series
        points = []
    return SentimentTrendOut(points=points)
