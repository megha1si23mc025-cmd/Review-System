
# backend/app/api/business.py
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from datetime import datetime, date, timedelta
from typing import List
from app.db.session import get_db
from app.schemas.personas import (
    BusinessTrendOut, BusinessCompareOut, ProductCompareItem, CountItem,
)
router = APIRouter()

def _parse_date(s: str | None) -> date | None:
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            continue
    try:
        return datetime.fromisoformat(s).date()
    except Exception:
        return None

@router.get("/category/{category}/trends", response_model=BusinessTrendOut)
def category_trends(
    category: str,
    start: str | None = None,
    end: str | None = None,
    db: Session = Depends(get_db),
):
    s_dt = _parse_date(start)
    e_dt = _parse_date(end)
    where = ["p.category = :cat"]
    params = {"cat": category}
    if s_dt:
        where.append("m.day >= :start")
        params["start"] = s_dt
    if e_dt:
        where.append("m.day <= :end")
        params["end"] = e_dt
    q = text(f"""
        SELECT m.day, m.sentiment, SUM(m.count) AS cnt
        FROM mv_product_sentiment_daily m
        JOIN products p ON p.id = m.product_id
        WHERE {' AND '.join(where)}
        GROUP BY m.day, m.sentiment
        ORDER BY m.day, m.sentiment
    """)
    try:
        rows = db.execute(q, params).all()
        points = [{"date": str(r[0]), "sentiment": str(r[1]), "count": int(r[2])} for r in rows]
    except Exception:
        points = []
    return BusinessTrendOut(points=points)

@router.get("/compare", response_model=BusinessCompareOut)
def compare_products(
    product_ids: str = Query(..., description="Comma-separated product IDs"),
    db: Session = Depends(get_db),
):
    try:
        ids: List[int] = [int(x) for x in product_ids.split(",") if x.strip()]
    except Exception:
        ids = []
    if not ids:
        return BusinessCompareOut(items=[])

    q_avg = text("""
        SELECT product_id, AVG(rating)::float AS avg_rating
        FROM reviews
        WHERE product_id = ANY(:ids) AND rating IS NOT NULL
        GROUP BY product_id
    """)
    avg_map = {int(pid): float(avg or 0.0) for pid, avg in db.execute(q_avg, {"ids": ids}).all()}

    q_issues = text("""
        SELECT r.product_id, lower(elem->>'theme') AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL jsonb_array_elements(a.key_themes) AS elem
        WHERE r.product_id = ANY(:ids)
        GROUP BY r.product_id, label
        ORDER BY r.product_id, cnt DESC
    """)
    issue_rows = db.execute(q_issues, {"ids": ids}).all()
    issues_map: dict[int, list[CountItem]] = {pid: [] for pid in ids}
    for pid, label, cnt in issue_rows:
        lst = issues_map.setdefault(int(pid), [])
        if len(lst) < 5:
            lst.append(CountItem(label=str(label), count=int(cnt)))

    end_dt = datetime.utcnow().date()
    start_dt = end_dt - timedelta(days=30)
    q_trend = text("""
        SELECT product_id, day, sentiment, count
        FROM mv_product_sentiment_daily
        WHERE product_id = ANY(:ids)
          AND day >= :start AND day <= :end
        ORDER BY product_id, day, sentiment
    """)
    try:
        trows = db.execute(q_trend, {"ids": ids, "start": start_dt, "end": end_dt}).all()
        trend_map: dict[int, list[dict]] = {pid: [] for pid in ids}
        for pid, day, s, cnt in trows:
            trend_map.setdefault(int(pid), []).append({
                "date": str(day), "sentiment": str(s), "count": int(cnt)
            })
    except Exception:
        trend_map = {pid: [] for pid in ids}

    items = []
    for pid in ids:
        items.append(ProductCompareItem(
            product_id=int(pid),
            average_rating=avg_map.get(int(pid)),
            issues_top=issues_map.get(int(pid), []),
            last30_trend=trend_map.get(int(pid), []),
        ))
    return BusinessCompareOut(items=items)

# ---- NEW: Seller-level insights (supplier-level) ----
@router.get("/seller/{seller_id}/insights", response_model=dict)
def seller_insights_aggregate(
    seller_id: int,
    start: str | None = None,
    end: str | None = None,
    topk: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
):
    s_dt = _parse_date(start)
    e_dt = _parse_date(end)

    # Average rating across seller's products
    q_avg = text("""
        SELECT AVG(r.rating)::float
        FROM reviews r
        JOIN products p ON p.id = r.product_id
        WHERE p.seller_id = :sid AND r.rating IS NOT NULL
    """)
    avg_rating = db.execute(q_avg, {"sid": seller_id}).scalar()

    # Sentiment distribution across seller
    q_dist = text("""
        SELECT COALESCE(a.sentiment, 'unknown') AS s, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        JOIN products p ON p.id = r.product_id
        WHERE p.seller_id = :sid
        GROUP BY s
        ORDER BY cnt DESC
    """)
    dist_rows = db.execute(q_dist, {"sid": seller_id}).all()
    sentiment_distribution = [{"label": str(x[0]), "count": int(x[1])} for x in dist_rows]

    # Top pros / cons across seller
    q_pros = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        JOIN products p ON p.id = r.product_id
        CROSS JOIN LATERAL jsonb_array_elements(a.pros) AS elem
        WHERE p.seller_id = :sid
          AND a.pros IS NOT NULL
          AND jsonb_typeof(a.pros)='array' AND jsonb_typeof(elem)='string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :k
    """)
    pros_rows = db.execute(q_pros, {"sid": seller_id, "k": topk}).all()
    pros_top = [{"label": str(x[0]), "count": int(x[1])} for x in pros_rows]

    q_cons = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        JOIN products p ON p.id = r.product_id
        CROSS JOIN LATERAL jsonb_array_elements(a.cons) AS elem
        WHERE p.seller_id = :sid
          AND a.cons IS NOT NULL
          AND jsonb_typeof(a.cons)='array' AND jsonb_typeof(elem)='string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :k
    """)
    cons_rows = db.execute(q_cons, {"sid": seller_id, "k": topk}).all()
    cons_top = [{"label": str(x[0]), "count": int(x[1])} for x in cons_rows]

    # Trend for seller: sum across their products (if MV exists)
    where = ["p.seller_id = :sid"]
    params = {"sid": seller_id}
    if s_dt:
        where.append("m.day >= :start"); params["start"] = s_dt
    if e_dt:
        where.append("m.day <= :end"); params["end"] = e_dt
    q_trend = text(f"""
        SELECT m.day, m.sentiment, SUM(m.count) AS cnt
        FROM mv_product_sentiment_daily m
        JOIN products p ON p.id = m.product_id
        WHERE {' AND '.join(where)}
        GROUP BY m.day, m.sentiment
        ORDER BY m.day, m.sentiment
    """)
    try:
        trows = db.execute(q_trend, params).all()
        trend_points = [{"date": str(d), "sentiment": str(s), "count": int(c)} for d, s, c in trows]
    except Exception:
        trend_points = []

    return {
        "seller_id": seller_id,
        "average_rating": float(avg_rating) if avg_rating is not None else None,
        "sentiment_distribution": sentiment_distribution,
        "pros_top": pros_top,
        "cons_top": cons_top,
        "trend_points": trend_points,
    }

# ---- NEW: Compare sellers ----
@router.get("/sellers/compare", response_model=dict)
def compare_sellers(
    seller_ids: str = Query(..., description="Comma-separated seller IDs"),
    db: Session = Depends(get_db),
):
    try:
        ids: List[int] = [int(x) for x in seller_ids.split(",") if x.strip()]
    except Exception:
        ids = []
    if not ids:
        return {"items": []}

    # Avg ratings
    q_avg = text("""
        SELECT p.seller_id, AVG(r.rating)::float
        FROM reviews r
        JOIN products p ON p.id = r.product_id
        WHERE p.seller_id = ANY(:ids) AND r.rating IS NOT NULL
        GROUP BY p.seller_id
    """)
    avg_map = {int(sid): float(avg or 0.0) for sid, avg in db.execute(q_avg, {"ids": ids}).all()}

    # Top issues (themes) per seller
    q_issues = text("""
        SELECT p.seller_id, lower(elem->>'theme') AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        JOIN products p ON p.id = r.product_id
        CROSS JOIN LATERAL jsonb_array_elements(a.key_themes) AS elem
        WHERE p.seller_id = ANY(:ids)
        GROUP BY p.seller_id, label
        ORDER BY p.seller_id, cnt DESC
    """)
    imap: dict[int, list[dict]] = {sid: [] for sid in ids}
    for sid, label, cnt in db.execute(q_issues, {"ids": ids}).all():
        lst = imap.setdefault(int(sid), [])
        if len(lst) < 5:
            lst.append({"label": str(label), "count": int(cnt)})

    # Last 30-day trend rollup per seller
    end_dt = datetime.utcnow().date()
    start_dt = end_dt - timedelta(days=30)
    q_trend = text("""
        SELECT p.seller_id, m.day, m.sentiment, SUM(m.count) AS cnt
        FROM mv_product_sentiment_daily m
        JOIN products p ON p.id = m.product_id
        WHERE p.seller_id = ANY(:ids) AND m.day >= :start AND m.day <= :end
        GROUP BY p.seller_id, m.day, m.sentiment
        ORDER BY p.seller_id, m.day, m.sentiment
    """)
    tmap: dict[int, list[dict]] = {sid: [] for sid in ids}
    try:
        for sid, d, s, c in db.execute(q_trend, {"ids": ids, "start": start_dt, "end": end_dt}).all():
            tmap.setdefault(int(sid), []).append({"date": str(d), "sentiment": str(s), "count": int(c)})
    except Exception:
        pass

    out = []
    for sid in ids:
        out.append({
            "seller_id": sid,
            "average_rating": avg_map.get(sid),
            "issues_top": imap.get(sid, []),
            "last30_trend": tmap.get(sid, []),
        })
    return {"items": out}
