
# backend/app/api/reviews.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from app.db.session import get_db
from app.models.product import Product
from app.models.review import Review
from app.schemas.review import ReviewCreate, ReviewOut
from app.api.auth import require_role, get_current_user

router = APIRouter()

@router.post("/", response_model=dict)
def create_review(
    payload: ReviewCreate,
    db: Session = Depends(get_db),
    user = Depends(require_role("buyer", "admin")),
):
    product = db.get(Product, payload.product_id)
    if not product:
        raise HTTPException(404, "Product not found")

    # Strict date parsing (same as imports)
    review_date = None
    raw_date = payload.review_date
    if raw_date:
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
            try:
                review_date = datetime.strptime(raw_date, fmt).date()
                break
            except Exception:
                continue
        if review_date is None:
            try:
                review_date = datetime.fromisoformat(raw_date).date()
            except Exception:
                review_date = None
    if review_date is None:
        raise HTTPException(400, "Invalid review_date")

    r = Review(
        product_id=payload.product_id,
        rating=payload.rating,
        review_title=payload.review_title,
        review_text=payload.review_text or "",
        review_date=review_date,
        reviewer_name=payload.reviewer_name or (user.full_name or user.email if user else None),
        verified_purchase=payload.verified_purchase,
        helpful_votes=payload.helpful_votes or 0,
        source=payload.source or "web",
    )
    db.add(r); db.commit(); db.refresh(r)
    return {"id": r.id}

@router.get("/product/{product_id}", response_model=list[ReviewOut])
def list_reviews_for_product(product_id: int, db: Session = Depends(get_db)):
    reviews = (
        db.query(Review)
        .filter(Review.product_id == product_id)
        .order_by(Review.review_date.desc())
        .limit(100)
        .all()
    )
    out = []
    for r in reviews:
        out.append(ReviewOut(
            id=r.id, product_id=r.product_id, rating=r.rating,
            review_title=r.review_title, review_text=r.review_text,
            review_date=str(r.review_date), reviewer_name=r.reviewer_name,
            verified_purchase=r.verified_purchase, helpful_votes=r.helpful_votes,
            source=r.source
        ))
    return out
