
# backend/app/api/admin.py
from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db
import io, csv, json
from datetime import datetime

router = APIRouter()

@router.post("/import/products")
async def import_products_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    from app.models.product import Product
    created, updated = 0, 0
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        product_title = (row.get("product_title") or "").strip()
        brand = (row.get("brand") or None)
        if brand:
            brand = brand.strip()
        category = (row.get("category") or "Electronics").strip()
        subtype = (row.get("subtype") or None)
        if subtype:
            subtype = subtype.strip()
        raw_price = row.get("price")
        sku_asin = (row.get("sku_asin") or None)
        if sku_asin:
            sku_asin = sku_asin.strip()

        price = None
        if raw_price not in (None, ""):
            try:
                price = float(raw_price)
            except Exception:
                price = None

        if not sku_asin:
            continue

        p = db.query(Product).filter(Product.sku == sku_asin).first()
        if p:
            p.external_id = ext_pid or p.external_id
            p.product_title = product_title or p.product_title
            p.brand = brand or p.brand
            p.category = category or p.category
            p.subtype = subtype or p.subtype
            p.price = price if price is not None else p.price
            p.source = (row.get("source") or p.source)
            updated += 1
        else:
            db.add(Product(
                external_id=ext_pid or None,
                sku=sku_asin,
                product_title=product_title,
                brand=brand,
                category=category,
                subtype=subtype,
                price=price,
                source=row.get("source") or "csv",
            ))
            created += 1
    db.commit()
    return {"created": created, "updated": updated}

@router.post("/import/reviews")
async def import_reviews_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    from app.models.review import Review
    from app.models.product import Product
    created, updated, skipped = 0, 0, 0
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    for row in reader:
        ext_rid = (row.get("review_id") or "").strip()
        prod_ext_id = (row.get("product_id") or "").strip()
        if not prod_ext_id:
            skipped += 1
            continue
        product = db.query(Product).filter(Product.external_id == prod_ext_id).first()
        if product is None and row.get("sku_asin"):
            product = db.query(Product).filter(Product.sku == row.get("sku_asin")).first()
        if not product:
            skipped += 1
            continue

        review_date = None
        raw_date = row.get("review_date")
        if raw_date:
            for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
                try:
                    review_date = datetime.strptime(raw_date, fmt).date()
                    break
                except Exception:
                    continue
            if review_date is None:
                try:
                    review_date = datetime.fromisoformat(raw_date).date()
                except Exception:
                    review_date = None
        if review_date is None:
            skipped += 1
            continue

        rating = None
        if row.get("rating") not in (None, ""):
            try:
                rating = int(row["rating"])
            except Exception:
                rating = None

        verified = str(row.get("verified_purchase")).strip().lower() in ("true","t","yes","y","1")
        helpful = 0
        if row.get("helpful_votes") not in (None, ""):
            try:
                helpful = int(row["helpful_votes"])
            except Exception:
                helpful = 0

        source = row.get("source") or "csv"

        existing = (
            db.query(Review)
            .filter(Review.source == source, Review.external_id == ext_rid)
            .first()
        )
        if existing:
            existing.product_id = product.id
            existing.rating = rating
            existing.review_title = row.get("review_title")
            existing.review_text = row.get("review_text") or ""
            existing.review_date = review_date
            existing.reviewer_name = row.get("reviewer_name")
            existing.verified_purchase = verified
            existing.helpful_votes = helpful
            updated += 1
        else:
            db.add(Review(
                product_id=product.id,
                external_id=ext_rid or None,
                rating=rating,
                review_title=row.get("review_title"),
                review_text=row.get("review_text") or "",
                review_date=review_date,
                reviewer_name=row.get("reviewer_name"),
                verified_purchase=verified,
                helpful_votes=helpful,
                source=source,
            ))
            created += 1
    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}

@router.post("/import/reviews-json")
async def import_reviews_json(file: UploadFile = File(...), db: Session = Depends(get_db)):
    from app.models.review import Review
    from app.models.product import Product
    created, updated, skipped = 0, 0, 0
    raw = await file.read()
    try:
        items = json.loads(raw.decode("utf-8"))
    except Exception:
        return {"error": "Invalid JSON"}
    if not isinstance(items, list):
        return {"error": "JSON must be an array"}

    for row in items:
        ext_rid = str(row.get("review_id") or "").strip()
        prod_ext_id = str(row.get("product_id") or "").strip()
        if not prod_ext_id or not ext_rid:
            skipped += 1
            continue

        product = db.query(Product).filter(Product.external_id == prod_ext_id).first()
        if not product:
            skipped += 1
            continue

        review_date = None
        raw_date = row.get("review_date")
        if raw_date:
            for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
                try:
                    review_date = datetime.strptime(raw_date, fmt).date()
                    break
                except Exception:
                    continue
            if review_date is None:
                try:
                    review_date = datetime.fromisoformat(raw_date).date()
                except Exception:
                    review_date = None
        if review_date is None:
            skipped += 1
            continue

        rating = None
        if row.get("rating") not in (None, ""):
            try:
                rating = int(row["rating"])
            except Exception:
                rating = None

        verified = bool(row.get("verified_purchase"))
        try:
            helpful = int(row.get("helpful_votes") or 0)
        except Exception:
            helpful = 0

        source = str(row.get("source") or "json")

        existing = (
            db.query(Review)
            .filter(Review.source == source, Review.external_id == ext_rid)
            .first()
        )
        if existing:
            existing.product_id = product.id
            existing.rating = rating
            existing.review_title = row.get("review_title")
            existing.review_text = row.get("review_text") or ""
            existing.review_date = review_date
            existing.reviewer_name = row.get("reviewer_name")
            existing.verified_purchase = verified
            existing.helpful_votes = helpful
            updated += 1
        else:
            db.add(Review(
                product_id=product.id,
                external_id=ext_rid,
                rating=rating,
                review_title=row.get("review_title"),
                review_text=row.get("review_text") or "",
                review_date=review_date,
                reviewer_name=row.get("reviewer_name"),
                verified_purchase=verified,
                helpful_votes=helpful,
                source=source,
            ))
            created += 1

    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}

# ---- NEW: import sellers.csv ----
@router.post("/import/sellers")
async def import_sellers_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """
    CSV headers: external_id,name,email
    """
    from app.models.seller import Seller
    created, updated = 0, 0
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    for row in reader:
        ext = (row.get("external_id") or "").strip()
        if not ext:
            continue
        name = (row.get("name") or "").strip() or "Unknown"
        email = (row.get("email") or None)
        if email:
            email = email.strip()
        s = db.query(Seller).filter(Seller.external_id == ext).first()
        if s:
            s.name = name or s.name
            s.email = email or s.email
            updated += 1
        else:
            db.add(Seller(external_id=ext, name=name, email=email))
            created += 1
    db.commit()
    return {"created": created, "updated": updated}

# ---- NEW: import product FAQs through admin (delegates to /faq router typically) ----
@router.post("/import/faq-questions")
async def import_faq_questions_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    from app.models.product import Product
    from app.models.faq import ProductQuestion
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        if not ext_pid or not qtext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        db.add(ProductQuestion(product_id=p.id, question_text=qtext))
        created += 1
    db.commit()
    return {"created": created}

@router.post("/import/faq-answers")
async def import_faq_answers_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    from app.models.product import Product
    from app.models.faq import ProductQuestion, ProductAnswer
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        atext = (row.get("answer_text") or "").strip()
        if not ext_pid or not qtext or not atext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        q = (
            db.query(ProductQuestion)
            .filter(ProductQuestion.product_id == p.id, ProductQuestion.question_text == qtext)
            .first()
        )
        if not q:
            q = ProductQuestion(product_id=p.id, question_text=qtext)
            db.add(q); db.flush()
        db.add(ProductAnswer(question_id=q.id, answer_text=atext))
        created += 1
    db.commit()
    return {"created": created}

@router.post("/refresh/materialized-views")
def refresh_materialized_views(db: Session = Depends(get_db)):
    """
    Create (if missing) and refresh mv_product_sentiment_daily.
    """
    try:
        db.execute(text("REFRESH MATERIALIZED VIEW mv_product_sentiment_daily"))
        db.commit()
        return {"status": "ok", "action": "refreshed"}
    except Exception:
        pass

    create_mv = text("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS mv_product_sentiment_daily AS
        SELECT
          r.product_id,
          r.review_date::date AS day,
          CASE
            WHEN r.rating IS NULL THEN 'unknown'
            WHEN r.rating <= 2 THEN 'negative'
            WHEN r.rating = 3 THEN 'neutral'
            WHEN r.rating >= 4 THEN 'positive'
            ELSE 'unknown'
          END AS sentiment,
          COUNT(*) AS count
        FROM reviews r
        WHERE r.review_date IS NOT NULL
        GROUP BY r.product_id, r.review_date::date,
                 CASE
                   WHEN r.rating IS NULL THEN 'unknown'
                   WHEN r.rating <= 2 THEN 'negative'
                   WHEN r.rating = 3 THEN 'neutral'
                   WHEN r.rating >= 4 THEN 'positive'
                   ELSE 'unknown'
                 END;
    """)
    db.execute(create_mv)
    db.execute(text("CREATE INDEX IF NOT EXISTS ix_mv_psd_prod_day ON mv_product_sentiment_daily(product_id, day)"))
    db.commit()

    try:
        db.execute(text("REFRESH MATERIALIZED VIEW mv_product_sentiment_daily"))
        db.commit()
        return {"status": "ok", "action": "created_and_refreshed"}
    except Exception as e:
        db.rollback()
        return {"status": "partial", "error": str(e)}

# backend/app/api/admin.py
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text, select
from app.db.session import get_db
import io, csv, json
from datetime import datetime
from app.api.auth import require_role  # reuse role guard
from app.core.security import hash_password, generate_temp_password
from app.models.user import User
from app.models.seller import Seller
from app.schemas.auth import AdminCreateSellerUserRequest

# ... (existing import endpoints unchanged above) ...

# NEW: Admin creates seller user (invite-only)
@router.post("/users/create-seller", response_model=dict)
def admin_create_seller_user(payload: AdminCreateSellerUserRequest, db: Session = Depends(get_db), _=Depends(require_role("admin"))):
    seller = db.execute(select(Seller).where(Seller.external_id == payload.seller_external_id)).scalar_one_or_none()
    if not seller:
        raise HTTPException(400, "Unknown seller_external_id")

    exists = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if exists:
        raise HTTPException(400, "Email already exists")

    temp_password = generate_temp_password()
    u = User(
        email=payload.email,
        full_name=payload.full_name,
        password_hash=hash_password(temp_password),
        role="seller",
        seller_id=seller.id,
        must_change_password=True,
        is_active=True,
    )
    db.add(u); db.commit(); db.refresh(u)
    # Return temp password so admin can share out-of-band
    return {"user_id": u.id, "seller_id": seller.id, "temp_password": temp_password}

# NEW: Admin resets a user's password (e.g., a seller)
@router.post("/users/{user_id}/reset-password", response_model=dict)
def admin_reset_user_password(user_id: int, db: Session = Depends(get_db), _=Depends(require_role("admin"))):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    temp_password = generate_temp_password()
    u.password_hash = hash_password(temp_password)
    u.must_change_password = True
    db.add(u); db.commit()
    return {"status": "ok", "temp_password": temp_password}
