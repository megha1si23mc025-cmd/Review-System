
# backend/app/api/products.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Optional
from app.db.session import get_db
from app.models.product import Product
from app.schemas.product import ProductCreate, ProductOut

router = APIRouter()

@router.post("/", response_model=dict)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    exists = db.query(Product).filter(Product.sku == payload.sku).first()
    if exists:
        raise HTTPException(400, "SKU already exists")
    p = Product(**payload.model_dump())
    db.add(p); db.commit(); db.refresh(p)
    return {"id": p.id}

@router.get("/search", response_model=List[ProductOut])
def search_products(
    q: Optional[str] = Query(None, description="Search by title, brand, or SKU"),
    limit: int = Query(50, ge=1, le=200),
    seller_id: Optional[int] = Query(None, description="Filter by seller id"),
    db: Session = Depends(get_db),
):
    if q is None or q.strip() == "":
        return []

    where = ["(product_title ILIKE :qq OR brand ILIKE :qq OR sku ILIKE :qq)"]
    params = {"qq": f"%{q.strip()}%", "lim": limit}
    if seller_id is not None:
        where.append("seller_id = :sid")
        params["sid"] = int(seller_id)

    sql = text(f"""
        SELECT id, sku, product_title, brand, category, price, source, external_id, subtype
        FROM products
        WHERE {' AND '.join(where)}
        ORDER BY id ASC
        LIMIT :lim
    """)
    rows = db.execute(sql, params).all()
    out: List[ProductOut] = []
    for r in rows:
        out.append(ProductOut(
            id=int(r[0]),
            sku=str(r[1]),
            product_title=str(r[2]),
            brand=(str(r[3]) if r[3] is not None else None),
            category=str(r[4]),
            price=(float(r[5]) if r[5] is not None else None),
            source=(str(r[6]) if r[6] is not None else None),
            external_id=(str(r[7]) if r[7] is not None else None),
            subtype=(str(r[8]) if r[8] is not None else None),
        ))
    return out

@router.get("/", response_model=List[ProductOut])
def list_products(
    limit: int = Query(50, ge=1, le=200),
    seller_id: Optional[int] = Query(None, description="Filter by seller id"),
    db: Session = Depends(get_db),
):
    q = db.query(Product)
    if seller_id is not None:
        q = q.filter(Product.seller_id == int(seller_id))
    items = q.order_by(Product.id.asc()).limit(limit).all()
    return [
        ProductOut(
            id=p.id, sku=p.sku, product_title=p.product_title, brand=p.brand,
            category=p.category, price=float(p.price) if p.price is not None else None,
            source=p.source, external_id=p.external_id, subtype=p.subtype
        )
        for p in items
    ]

@router.get("/by-id/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")
    return ProductOut(
        id=p.id, sku=p.sku, product_title=p.product_title, brand=p.brand,
        category=p.category, price=float(p.price) if p.price is not None else None,
        source=p.source, external_id=p.external_id, subtype=p.subtype
    )
