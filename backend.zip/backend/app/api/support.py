
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db
from app.schemas.personas import SupportListOut, SupportIssueOut

router = APIRouter()

NEGATIVE_KEYWORDS = (
    "broken", "stopped", "refund", "return", "defect", "doesn't work",
    "doesnt work", "dead", "damaged", "warranty", "noise", "overheating", "heating",
)


def _severity(sentiment: str, helpful: int, text_excerpt: str) -> int:
    base = 1
    if sentiment == "negative":
        base += 2
    elif sentiment == "neutral":
        base += 0
    # keyword bumps
    low = text_excerpt.lower()
    if any(k in low for k in NEGATIVE_KEYWORDS):
        base += 1
    # helpful votes bump
    if helpful >= 10:
        base += 2
    elif helpful >= 5:
        base += 1
    return min(base, 5)


@router.get("/product/{product_id}/urgent", response_model=SupportListOut)
def product_urgent(
    product_id: int,
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating, r.reviewer_name,
               r.helpful_votes, COALESCE(a.sentiment, 'unknown') AS s,
               (SELECT elem->>'theme'
                  FROM jsonb_array_elements(a.key_themes) AS elem
                  LIMIT 1) AS top_issue,
               r.review_text
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE r.product_id = :pid
          AND (a.sentiment = 'negative' OR a.sentiment = 'neutral')
        ORDER BY (CASE WHEN a.sentiment='negative' THEN 1 ELSE 2 END),
                 r.helpful_votes DESC, r.review_date DESC
        LIMIT :lim
    """)
    rows = db.execute(q, {"pid": product_id, "lim": limit}).all()
    items = []
    for rid, pid, d, rating, name, hv, s, issue, txt in rows:
        excerpt = (txt or "").strip()
        if len(excerpt) > 280:
            excerpt = excerpt[:277] + "..."
        sev = _severity(s or "unknown", int(hv or 0), excerpt)
        items.append(SupportIssueOut(
            review_id=int(rid),
            product_id=int(pid),
            review_date=str(d),
            rating=int(rating) if rating is not None else None,
            reviewer_name=name,
            helpful_votes=int(hv or 0),
            sentiment=s or "unknown",
            top_issue=issue,
            severity=sev,
            excerpt=excerpt or "(no text)",
        ))
    return SupportListOut(items=items)


@router.get("/reviews/negative", response_model=SupportListOut)
def global_negative(
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating, r.reviewer_name,
               r.helpful_votes, COALESCE(a.sentiment, 'unknown') AS s,
               (SELECT elem->>'theme'
                  FROM jsonb_array_elements(a.key_themes) AS elem
                  LIMIT 1) AS top_issue,
               r.review_text
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE a.sentiment = 'negative'
        ORDER BY r.helpful_votes DESC, r.review_date DESC
        LIMIT :lim
    """)
    rows = db.execute(q, {"lim": limit}).all()
    items = []
    for rid, pid, d, rating, name, hv, s, issue, txt in rows:
        excerpt = (txt or "").strip()
        if len(excerpt) > 280:
            excerpt = excerpt[:277] + "..."
        sev = _severity(s or "unknown", int(hv or 0), excerpt)
        items.append(SupportIssueOut(
            review_id=int(rid),
            product_id=int(pid),
            review_date=str(d),
            rating=int(rating) if rating is not None else None,
            reviewer_name=name,
            helpful_votes=int(hv or 0),
            sentiment=s or "unknown",
            top_issue=issue,
            severity=sev,
            excerpt=excerpt or "(no text)",
        ))
    return SupportListOut(items=items)
