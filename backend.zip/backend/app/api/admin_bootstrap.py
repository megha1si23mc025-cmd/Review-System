
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db
from app.models.analysis import Analysis
from app.schemas.analysis import AnalysisCreate

router = APIRouter()

# Simple keyword sets (customize per domain)
PRO_KEYWORDS = (
    "good", "great", "excellent", "value", "budget", "quiet", "cooling",
    "durable", "comfortable", "easy", "works", "fast", "performance", "quality",
)
CON_KEYWORDS = (
    "bad", "poor", "cheap", "plastic", "noisy", "noise", "broken", "stopped",
    "defect", "slow", "heat", "overheating", "confusing", "difficult", "return",
    "refund", "warranty",
)

def infer_sentiment_from_rating(rating: int | None) -> str:
    if rating is None:
        return "neutral"
    if rating >= 4:
        return "positive"
    if rating <= 2:
        return "negative"
    return "neutral"

def extract_pros_cons(text: str) -> tuple[list[str], list[str]]:
    low = (text or "").lower()
    pros, cons = [], []
    for kw in PRO_KEYWORDS:
        if kw in low:
            pros.append(kw)
    for kw in CON_KEYWORDS:
        if kw in low:
            cons.append(kw)
    # Deduplicate, keep top 5
    pros = sorted(set(pros))[:5]
    cons = sorted(set(cons))[:5]
    return pros, cons

def _bootstrap_analyses(
    db: Session,
    product_id: int | None,
    limit: int,
) -> dict:
    """
    Create/refresh Analysis rows WITHOUT LLM using simple heuristics:
    - sentiment from rating
    - pros/cons from keyword matching
    - short summary/verdict
    """
    params: dict = {"lim": limit}
    where = []
    if product_id is not None:
        where.append("r.product_id = :pid")
        params["pid"] = product_id

    q = f"""
    SELECT r.id, r.product_id, r.rating, r.review_title, r.review_text, r.review_date
    FROM reviews r
    {('WHERE ' + ' AND '.join(where)) if where else ''}
    ORDER BY r.review_date DESC, r.id DESC
    LIMIT :lim
    """
    rows = db.execute(text(q), params).all()

    created = 0
    updated = 0
    scanned = len(rows)

    for rid, pid, rating, title, review_text, dt in rows:
        sentiment = infer_sentiment_from_rating(rating)
        pros, cons = extract_pros_cons(review_text or "")

        summary = None
        verdict = {
            "positive": "Overall favorable customer sentiment.",
            "neutral": "Mixed feedback; consider details.",
            "negative": "Multiple concerns reported by customers.",
        }.get(sentiment, "Mixed feedback; consider details.")
        if pros and cons:
            summary = f"Customers mention {', '.join(pros)}; concerns include {', '.join(cons)}."
        elif pros:
            summary = f"Frequent positives: {', '.join(pros)}."
        elif cons:
            summary = f"Common issues: {', '.join(cons)}."

        payload = AnalysisCreate(
            review_id=int(rid),
            llm_model="bootstrap/heuristics",
            provider="offline",
            prompt_version="v0",
            summary=summary,
            pros=pros or None,
            cons=cons or None,
            sentiment=sentiment,
            verdict=verdict,
            key_themes=[{"theme": t} for t in (pros + cons)][:5] or None,
            raw_output={"source": "bootstrap", "rating": rating},
        ).model_dump()

        existing = db.query(Analysis).filter(Analysis.review_id == rid).first()
        if existing:
            for k, v in payload.items():
                setattr(existing, k, v)
            updated += 1
        else:
            db.add(Analysis(**payload))
            created += 1

    db.commit()
    return {"status": "ok", "created": created, "updated": updated, "scanned": scanned, "product_id": product_id}

@router.get("/bootstrap-analyses", response_model=dict)
def bootstrap_analyses_get(
    product_id: int | None = None,
    limit: int = Query(2000, ge=1, le=20000),
    db: Session = Depends(get_db),
):
    return _bootstrap_analyses(db, product_id, limit)

@router.post("/bootstrap-analyses", response_model=dict)
def bootstrap_analyses_post(
    product_id: int | None = None,
    limit: int = Query(2000, ge=1, le=20000),
    db: Session = Depends(get_db),
):
    return _bootstrap_analyses(db, product_id, limit)
