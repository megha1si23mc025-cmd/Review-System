
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.analysis import Analysis
from app.models.review import Review
from app.schemas.analysis import AnalysisCreate, AnalysisOut
from app.schemas.imports import AnalysisBulkItem
from typing import List

router = APIRouter()

@router.post("/", response_model=dict)
def upsert_analysis(payload: AnalysisCreate, db: Session = Depends(get_db)):
    review = db.get(Review, payload.review_id)
    if not review:
        raise HTTPException(404, "Review not found")
    existing = db.query(Analysis).filter(Analysis.review_id == payload.review_id).first()
    data = payload.model_dump()
    if existing:
        for k, v in data.items():
            setattr(existing, k, v)
        db.commit(); db.refresh(existing)
        return {"id": existing.id, "status": "updated"}
    a = Analysis(**data)
    db.add(a); db.commit(); db.refresh(a)
    return {"id": a.id, "status": "created"}

@router.get("/{review_id}", response_model=AnalysisOut)
def get_analysis(review_id: int, db: Session = Depends(get_db)):
    a = db.query(Analysis).filter(Analysis.review_id == review_id).first()
    if not a:
        raise HTTPException(404, "Analysis not found")
    return AnalysisOut(
        review_id=review_id,
        summary=a.summary, pros=a.pros, cons=a.cons,
        sentiment=a.sentiment, verdict=a.verdict,
        key_themes=a.key_themes
    )

@router.post("/bulk", response_model=dict)
def bulk_import_analyses(items: List[AnalysisBulkItem], db: Session = Depends(get_db)):
    count_created = 0
    count_updated = 0
    for item in items:
        review = db.get(Review, item.review_id)
        if not review:
            continue
        existing = db.query(Analysis).filter(Analysis.review_id == item.review_id).first()
        data = item.model_dump()
        if existing:
            for k, v in data.items():
                setattr(existing, k, v)
            count_updated += 1
        else:
            db.add(Analysis(**data))
            count_created += 1
    db.commit()
    return {"created": count_created, "updated": count_updated}
