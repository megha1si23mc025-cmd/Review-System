
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List
from app.db.session import get_db
from app.models.seller import Seller
from app.models.product import Product
from app.schemas.seller import SellerCreate, SellerOut
from app.schemas.product import ProductOut

router = APIRouter()

@router.post("/", response_model=dict)
def create_seller(payload: SellerCreate, db: Session = Depends(get_db)):
    exists = db.query(Seller).filter(Seller.external_id == payload.external_id).first()
    if exists:
        raise HTTPException(400, "Seller external_id already exists")
    s = Seller(**payload.model_dump())
    db.add(s); db.commit(); db.refresh(s)
    return {"id": s.id}

@router.get("/", response_model=List[SellerOut])
def list_sellers(limit: int = Query(100, ge=1, le=1000), db: Session = Depends(get_db)):
    rows = db.query(Seller).order_by(Seller.id.asc()).limit(limit).all()
    return [SellerOut(id=s.id, external_id=s.external_id, name=s.name, email=s.email) for s in rows]

@router.get("/{seller_id}/products", response_model=List[ProductOut])
def list_seller_products(seller_id: int, limit: int = Query(200, ge=1, le=1000), db: Session = Depends(get_db)):
    items = (
        db.query(Product)
        .filter(Product.seller_id == seller_id)
        .order_by(Product.id.asc())
        .limit(limit)
        .all()
    )
    return [
        ProductOut(
            id=p.id, sku=p.sku, product_title=p.product_title, brand=p.brand,
            category=p.category, price=float(p.price) if p.price is not None else None,
            source=p.source, external_id=p.external_id, subtype=p.subtype,
            # (If you later expose seller fields in ProductOut, add them here)
        )
        for p in items
    ]
