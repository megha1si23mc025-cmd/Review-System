
# backend/app/api/bootstrap_admin.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.db.session import get_db
from app.models.user import User
from app.core.security import hash_password

router = APIRouter()

@router.post("/bootstrap-admin", response_model=dict)
def bootstrap_admin(email: str, password: str, db: Session = Depends(get_db)):
    # Prevent accidental overwrite
    exists = db.execute(select(User).where(User.role == "admin")).scalar_one_or_none()
    if exists:
        raise HTTPException(400, "Admin already exists")

    u = User(
        email=email,
        full_name="Administrator",
        password_hash=hash_password(password),
        role="admin",
        is_active=True,
        must_change_password=False,
    )
    db.add(u)
    db.commit()
    return {"status": "admin_created", "email": email}
