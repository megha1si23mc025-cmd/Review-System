
# backend/app/api/seller.py
from fastapi import APIRouter, Depends, Query, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import text
from datetime import datetime, date
from app.db.session import get_db
from app.schemas.personas import SellerInsightsOut, CountItem
from app.models.product import Product
from app.api.auth import get_current_user, require_role
import io, csv

router = APIRouter()

def _parse_date(s: str | None) -> date | None:
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            continue
    try:
        return datetime.fromisoformat(s).date()
    except Exception:
        return None

# --- Helper: ensure the product belongs to the seller (or admin bypass) ---
def _assert_product_ownership(product_id: int, user, db: Session):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")
    if user.role != "admin" and p.seller_id != user.seller_id:
        raise HTTPException(403, "Forbidden: product not owned by seller")
    return p

# Existing insights endpoint, now role-protected to seller's own product
@router.get("/product/{product_id}/insights", response_model=SellerInsightsOut)
def seller_insights(
    product_id: int,
    start: str | None = None,
    end: str | None = None,
    topk: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
    user=Depends(require_role("seller", "admin")),
):
    _assert_product_ownership(product_id, user, db)

    # Pros aggregate
    q_pros = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL (
            SELECT e
            FROM jsonb_array_elements(a.pros) AS e
        ) AS t(elem)
        WHERE r.product_id = :pid
          AND a.pros IS NOT NULL
          AND jsonb_typeof(a.pros) = 'array'
          AND jsonb_typeof(elem) = 'string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :k
    """)
    pros_rows = db.execute(q_pros, {"pid": product_id, "k": topk}).all()
    pros = [CountItem(label=str(x[0]), count=int(x[1])) for x in pros_rows]

    # Cons aggregate
    q_cons = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL (
            SELECT e
            FROM jsonb_array_elements(a.cons) AS e
        ) AS t(elem)
        WHERE r.product_id = :pid
          AND a.cons IS NOT NULL
          AND jsonb_typeof(a.cons) = 'array'
          AND jsonb_typeof(elem) = 'string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :k
    """)
    cons_rows = db.execute(q_cons, {"pid": product_id, "k": topk}).all()
    cons = [CountItem(label=str(x[0]), count=int(x[1])) for x in cons_rows]

    # Sentiment distribution
    q_dist = text("""
        SELECT COALESCE(a.sentiment, 'unknown') AS s, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        WHERE r.product_id = :pid
        GROUP BY s
        ORDER BY cnt DESC
    """)
    dist_rows = db.execute(q_dist, {"pid": product_id}).all()
    dist = [CountItem(label=str(x[0]), count=int(x[1])) for x in dist_rows]

    # Key issues
    q_issues = text("""
        SELECT lower(elem->>'theme') AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL (
            SELECT e
            FROM jsonb_array_elements(a.key_themes) AS e
        ) AS t(elem)
        WHERE r.product_id = :pid
          AND a.key_themes IS NOT NULL
          AND jsonb_typeof(a.key_themes) = 'array'
          AND jsonb_typeof(elem) = 'object'
          AND (elem ? 'theme')
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :k
    """)
    issue_rows = db.execute(q_issues, {"pid": product_id, "k": topk}).all()
    issues = [CountItem(label=str(x[0]), count=int(x[1])) for x in issue_rows]

    # Trend from MV
    s_dt = _parse_date(start)
    e_dt = _parse_date(end)
    where = ["product_id = :pid"]
    params = {"pid": product_id}
    if s_dt:
        where.append("day >= :start"); params["start"] = s_dt
    if e_dt:
        where.append("day <= :end"); params["end"] = e_dt
    q_trend = text(f"""
        SELECT day, sentiment, count
        FROM mv_product_sentiment_daily
        WHERE {' AND '.join(where)}
        ORDER BY day, sentiment
    """)
    try:
        trows = db.execute(q_trend, params).all()
        points = [{"date": str(r[0]), "sentiment": str(r[1]), "count": int(r[2])} for r in trows]
    except Exception:
        points = []

    return SellerInsightsOut(
        product_id=product_id,
        pros_top=pros,
        cons_top=cons,
        sentiment_distribution=dist,
        key_issues=issues,
        trend_points=points,
    )

# NEW: Seller lists only their products
@router.get("/me/products", response_model=list[dict])
def seller_my_products(
    db: Session = Depends(get_db),
    user=Depends(require_role("seller", "admin")),
):
    if user.role == "admin":
        q = db.query(Product).order_by(Product.id.asc()).limit(500).all()
    else:
        q = db.query(Product).filter(Product.seller_id == user.seller_id).order_by(Product.id.asc()).limit(500).all()
    return [
        {
            "id": p.id, "sku": p.sku, "product_title": p.product_title, "brand": p.brand,
            "category": p.category, "subtype": p.subtype,
            "price": float(p.price) if p.price is not None else None,
            "external_id": p.external_id, "source": p.source
        } for p in q
    ]

# NEW: Seller creates a product tied to their seller_id
@router.post("/products", response_model=dict)
def seller_create_product(
    payload: dict,
    db: Session = Depends(get_db),
    user=Depends(require_role("seller", "admin")),
):
    # Expected payload keys: sku, product_title, brand?, category?, subtype?, price?, external_id?
    required = ["sku", "product_title"]
    for k in required:
        if not payload.get(k):
            raise HTTPException(400, f"Missing {k}")

    exists = db.query(Product).filter(Product.sku == payload["sku"]).first()
    if exists:
        raise HTTPException(400, "SKU already exists")

    p = Product(
        sku=payload["sku"].strip(),
        product_title=payload["product_title"].strip(),
        brand=(payload.get("brand") or None),
        category=(payload.get("category") or "Electronics"),
        subtype=(payload.get("subtype") or None),
        price=(float(payload["price"]) if payload.get("price") not in (None, "") else None),
        external_id=(payload.get("external_id") or None),
        source="seller",
        seller_id=(None if user.role == "admin" else user.seller_id),
    )
    if user.role == "admin" and payload.get("seller_id"):
        p.seller_id = int(payload["seller_id"])
    db.add(p); db.commit(); db.refresh(p)
    return {"id": p.id}

# NEW: Seller bulk import products (CSV) for self
@router.post("/products/import", response_model=dict)
async def seller_import_products_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user=Depends(require_role("seller", "admin")),
):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))

    created, updated, skipped = 0, 0, 0
    for row in reader:
        sku = (row.get("sku_asin") or row.get("sku") or "").strip()
        if not sku:
            skipped += 1
            continue
        p = db.query(Product).filter(Product.sku == sku).first()
        price = None
        if (row.get("price") or "").strip() != "":
            try:
                price = float(row["price"])
            except Exception:
                price = None
        if p:
            # Only allow update if owned by this seller or admin
            if user.role != "admin" and p.seller_id != user.seller_id:
                skipped += 1
                continue
            p.product_title = (row.get("product_title") or p.product_title)
            p.brand = (row.get("brand") or p.brand)
            p.category = (row.get("category") or p.category or "Electronics")
            p.subtype = (row.get("subtype") or p.subtype)
            p.price = price if price is not None else p.price
            updated += 1
        else:
            db.add(Product(
                external_id=(row.get("product_id") or None),
                sku=sku,
                product_title=(row.get("product_title") or ""),
                brand=(row.get("brand") or None),
                category=(row.get("category") or "Electronics"),
                subtype=(row.get("subtype") or None),
                price=price,
                source="seller-csv",
                seller_id=(None if user.role == "admin" else user.seller_id),
            ))
            created += 1
    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}



@router.get("/product/{product_id}/urgent", response_model=dict)
def seller_product_urgent(
    product_id: int,
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
    user=Depends(require_role("seller", "admin")),
):
    _assert_product_ownership(product_id, user, db)
    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating, r.reviewer_name,
               r.helpful_votes, COALESCE(a.sentiment, 'unknown') AS s,
               (SELECT elem->>'theme'
                  FROM jsonb_array_elements(a.key_themes) AS elem
                  LIMIT 1) AS top_issue,
               r.review_text
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE r.product_id = :pid
          AND (a.sentiment = 'negative' OR a.sentiment = 'neutral')
        ORDER BY (CASE WHEN a.sentiment='negative' THEN 1 ELSE 2 END),
                 r.helpful_votes DESC, r.review_date DESC
        LIMIT :lim
    """)
    rows = db.execute(q, {"pid": product_id, "lim": limit}).all()
    def _severity(sentiment: str, helpful: int, text_excerpt: str) -> int:
        base = 1
        if sentiment == "negative":
            base += 2
        low = (text_excerpt or "").lower()
        if any(k in low for k in ("broken","stopped","refund","return","defect","doesn't work","doesnt work","dead","damaged","warranty","noise","overheating","heating")):
            base += 1
        if helpful >= 10:
            base += 2
        elif helpful >= 5:
            base += 1
        return min(base, 5)
    items = []
    for rid, pid, d, rating, name, hv, s, issue, txt in rows:
        excerpt = (txt or "").strip()
        if len(excerpt) > 280:
            excerpt = excerpt[:277] + "..."
        sev = _severity(s or "unknown", int(hv or 0), excerpt)
        items.append({
            "review_id": int(rid),
            "product_id": int(pid),
            "review_date": str(d),
            "rating": int(rating) if rating is not None else None,
            "reviewer_name": name,
            "helpful_votes": int(hv or 0),
            "sentiment": s or "unknown",
            "top_issue": issue,
            "severity": sev,
            "excerpt": excerpt or "(no text)",
        })
    return {"items": items}
