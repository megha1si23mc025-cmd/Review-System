
# backend/app/api/routes.py
from fastapi import APIRouter
from . import products, reviews, analyses, dashboards, admin
from . import buyer, seller, support, business
from . import admin_bootstrap
from . import sellers
from . import auth       # NEW
from . import faq        # NEW
from . import bootstrap_admin 
api_router = APIRouter()

  # ADD THIS

api_router.include_router(bootstrap_admin.router, prefix="/admin", tags=["admin"])  # TEMPORARILY

api_router.include_router(auth.router,         prefix="/auth",       tags=["auth"])         # NEW
api_router.include_router(faq.router,          prefix="/faq",        tags=["faq"])          # NEW

api_router.include_router(products.router,     prefix="/products",   tags=["products"])
api_router.include_router(reviews.router,      prefix="/reviews",    tags=["reviews"])
api_router.include_router(analyses.router,     prefix="/analyses",   tags=["analyses"])
api_router.include_router(dashboards.router,   prefix="/dashboards", tags=["dashboards"])
api_router.include_router(admin.router,        prefix="/admin",      tags=["admin"])
api_router.include_router(sellers.router,      prefix="/sellers",    tags=["sellers"])

api_router.include_router(buyer.router,        prefix="/buyer",      tags=["buyer"])
api_router.include_router(seller.router,       prefix="/seller",     tags=["seller"])
api_router.include_router(support.router,      prefix="/support",    tags=["support"])
api_router.include_router(business.router,     prefix="/business",   tags=["business"])
api_router.include_router(admin_bootstrap.router, prefix="/admin",   tags=["admin"])
