
from sqlalchemy import Column, BigInteger, String, TIMESTAMP
from sqlalchemy.sql import func
from app.models.base import Base

class Seller(Base):
    __tablename__ = "sellers"
    id = Column(BigInteger, primary_key=True)
    external_id = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(128), nullable=False)
    email = Column(String(128))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
