
from sqlalchemy import Column, BigInteger, String, Text, Integer, TIMESTAMP, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.models.base import Base

class Analysis(Base):
    __tablename__ = "analyses"
    id = Column(BigInteger, primary_key=True)
    review_id = Column(BigInteger, ForeignKey("reviews.id", ondelete="CASCADE"), nullable=False, unique=True)
    llm_model = Column(String(128), nullable=False)
    provider = Column(String(64), default="huggingface")
    prompt_version = Column(String(64), default="v1")
    summary = Column(Text)
    pros = Column(JSONB)
    cons = Column(JSONB)
    sentiment = Column(String(32), nullable=False)  # positive | neutral | negative | unknown
    verdict = Column(String(512))
    key_themes = Column(JSONB)
    raw_output = Column(JSONB)
    tokens_input = Column(Integer)
    tokens_output = Column(Integer)
    latency_ms = Column(Integer)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    review = relationship("Review", backref="analysis")
