
from sqlalchemy import Column, BigInteger, Text, TIMESTAMP, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSONB
from app.models.base import Base

class ProductSnapshot(Base):
    __tablename__ = "product_snapshots"
    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), primary_key=True)
    last_computed_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
    sentiment_counts = Column(JSONB)
    top_pros = Column(JSONB)
    top_cons = Column(JSONB)
    top_themes = Column(JSONB)
    recent_summary = Column(Text)
