
from sqlalchemy import Column, BigInteger, String, Numeric, TIMESTAMP, Index, ForeignKey
from sqlalchemy.sql import func
from app.models.base import Base

class Product(Base):
    __tablename__ = "products"
    id = Column(BigInteger, primary_key=True)
    external_id = Column(String(64), unique=True, index=True)  # e.g., P0001318
    sku = Column(String(64), unique=False, index=True, nullable=False)  # sku_asin
    product_title = Column(String(256), nullable=False)
    brand = Column(String(128))
    category = Column(String(128), default="Electronics")
    subtype = Column(String(128))
    price = Column(Numeric(12,2))
    source = Column(String(64))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    # NEW: link to seller (nullable for legacy/unknown)
    seller_id = Column(BigInteger, ForeignKey("sellers.id", ondelete="SET NULL"), index=True, nullable=True)

    __table_args__ = (
        Index("ix_products_brand_category", "brand", "category"),
    )
