
# backend/app/models/user.py
from sqlalchemy import Column, BigInteger, String, TIMESTAMP, ForeignKey, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.models.base import Base

class User(Base):
    __tablename__ = "users"
    id = Column(BigInteger, primary_key=True)
    email = Column(String(256), unique=True, index=True, nullable=False)
    full_name = Column(String(256))
    password_hash = Column(String(512), nullable=False)
    role = Column(String(32), default="buyer", nullable=False)  # buyer|seller|admin
    seller_id = Column(BigInteger, ForeignKey("sellers.id", ondelete="SET NULL"), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)

    # NEW: invite / reset features
    must_change_password = Column(Boolean, default=False, nullable=False)
    reset_token = Column(String(128), nullable=True)
    reset_expires = Column(TIMESTAMP(timezone=True), nullable=True)

    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    seller = relationship("Seller", backref="users")
