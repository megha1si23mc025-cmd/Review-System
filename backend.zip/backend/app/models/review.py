
from sqlalchemy import Column, BigInteger, Integer, String, Text, Date, Boolean, TIMESTAMP, ForeignKey, Index
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.models.base import Base

class Review(Base):
    __tablename__ = "reviews"
    id = Column(BigInteger, primary_key=True)
    external_id = Column(String(64), index=True)  # R0000001
    source = Column(String(64), default="csv", nullable=False)

    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    rating = Column(Integer)
    review_title = Column(String(256))
    review_text = Column(Text, nullable=False)
    review_date = Column(Date, nullable=False)
    reviewer_name = Column(String(128))
    verified_purchase = Column(Boolean, default=False, nullable=False)
    helpful_votes = Column(Integer, default=0, nullable=False)
    language = Column(String(16), default="en")
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    product = relationship("Product", backref="reviews")
    __table_args__ = (
        Index("uq_reviews_source_external", "source", "external_id", unique=True),
        Index("ix_reviews_product_date", "product_id", "review_date"),
    )
