
#!/usr/bin/env python3
import argparse
import csv
import io
import requests

def login_admin(api_base: str, email: str, password: str) -> str:
    url = f"{api_base}/auth/login"
    r = requests.post(url, data={"username": email, "password": password}, timeout=30)
    r.raise_for_status()
    return r.json()["access_token"]

def tsv_to_csv_bytes(tsv_path: str, delimiter: str = "\t") -> bytes:
    # Converts TSV (external_id, name, email) to CSV with headers expected by /admin/import/sellers
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["external_id", "name", "email"])
    with open(tsv_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f, delimiter=delimiter)
        for row in reader:
            if not row or len(row) < 3: continue
            ext = (row[0] or "").strip()
            name = (row[1] or "").strip()
            email = (row[2] or "").strip()
            if not ext or not email: continue
            writer.writerow([ext, name, email])
    return buf.getvalue().encode("utf-8")

def import_sellers(api_base: str, token: str, csv_bytes: bytes) -> dict:
    url = f"{api_base}/admin/import/sellers"
    files = {"file": ("sellers-10.csv", csv_bytes, "text/csv")}
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.post(url, files=files, headers=headers, timeout=60)
    r.raise_for_status()
    return r.json()

def main():
    parser = argparse.ArgumentParser(description="Import sellers into DB from TSV/CSV.")
    parser.add_argument("--api", default="http://127.0.0.1:8001")
    parser.add_argument("--admin-email", required=True)
    parser.add_argument("--admin-password", required=True)
    parser.add_argument("--input", required=True, help="TSV/CSV file with external_id, name, email")
    parser.add_argument("--delimiter", default="\t")
    args = parser.parse_args()

    token = login_admin(args.api, args.admin_email, args.admin_password)
    csv_bytes = tsv_to_csv_bytes(args.input, args.delimiter)
    res = import_sellers(args.api, token, csv_bytes)
    print("[INFO] Import result:", res)

if __name__ == "__main__":
    main()
