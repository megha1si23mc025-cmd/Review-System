
#!/usr/bin/env python3
import argparse
import csv
import sys
import time
from typing import List, Dict, Optional
import requests

def login_admin(api_base: str, email: str, password: str) -> str:
    """Login as admin and return access token."""
    url = f"{api_base}/auth/login"
    data = {"username": email, "password": password}
    r = requests.post(url, data=data, timeout=30)
    if not r.ok:
        raise RuntimeError(f"Admin login failed: {r.status_code} {r.text}")
    token = r.json().get("access_token")
    if not token:
        raise RuntimeError("No access_token in admin login response.")
    return token

def create_seller_user(api_base: str, token: str, email: str, full_name: str, seller_external_id: str) -> Dict:
    """Call POST /admin/users/create-seller; return JSON dict."""
    url = f"{api_base}/admin/users/create-seller"
    payload = {
        "email": email,
        "full_name": full_name,
        "seller_external_id": seller_external_id,
    }
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"}
    r = requests.post(url, json=payload, headers=headers, timeout=30)
    if r.status_code == 200:
        return r.json()
    else:
        try:
            msg = r.json()
        except Exception:
            msg = r.text
        raise RuntimeError(f"Create seller user failed for {email}: {r.status_code} {msg}")

def read_dataset(input_path: str, delimiter: str = "\t") -> List[Dict[str, str]]:
    """
    Read seller dataset with 3 columns per line:
      external_id <tab> name <tab> email
    Example:
      S0000001\tSeller 1\tseller1@example.com
    """
    rows = []
    with open(input_path, "r", newline="", encoding="utf-8") as f:
        reader = csv.reader(f, delimiter=delimiter)
        for i, row in enumerate(reader, start=1):
            if not row or all((str(x or "").strip() == "" for x in row)):
                continue
            if len(row) < 3:
                print(f"[WARN] Line {i}: expected 3 columns (external_id, name, email), got {len(row)}", file=sys.stderr)
                continue
            ext, name, email = (row[0] or "").strip(), (row[1] or "").strip(), (row[2] or "").strip()
            if not ext or not email:
                print(f"[WARN] Line {i}: missing external_id or email", file=sys.stderr); continue
            rows.append({"external_id": ext, "name": name or None, "email": email})
    return rows

def write_output(output_path: str, records: List[Dict[str, Optional[str]]]) -> None:
    cols = ["email", "full_name", "seller_external_id", "user_id", "seller_id", "temp_password", "status"]
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for rec in records:
            w.writerow({k: rec.get(k) for k in cols})

def main():
    parser = argparse.ArgumentParser(description="Bulk-create seller users (with temp passwords) from TSV/CSV.")
    parser.add_argument("--api", default="http://127.0.0.1:8001", help="API base, e.g., http://127.0.0.1:8001")
    parser.add_argument("--admin-email", required=True, help="Admin email for login")
    parser.add_argument("--admin-password", required=True, help="Admin password for login")
    parser.add_argument("--input", required=True, help="Path to seller dataset (TSV/CSV)")
    parser.add_argument("--delimiter", default="\t", help="Field delimiter (default: tab '\\t'; use ',' for CSV)")
    parser.add_argument("--out", default="seller_temp_passwords.csv", help="Path to output CSV")
    parser.add_argument("--sleep-ms", type=int, default=0, help="Sleep between requests (milliseconds)")
    args = parser.parse_args()

    print(f"[INFO] Logging in as admin {args.admin_email} …")
    token = login_admin(args.api, args.admin_email, args.admin_password)

    print(f"[INFO] Reading dataset: {args.input}")
    items = read_dataset(args.input, args.delimiter)
    if not items:
        print("[ERROR] No valid rows found in dataset.", file=sys.stderr)
        sys.exit(1)

    out_records = []
    for i, row in enumerate(items, start=1):
        ext = row["external_id"]; nm = row["name"] or ""; em = row["email"]
        print(f"[{i}/{len(items)}] Creating user for {em} (seller_external_id={ext}) …")
        try:
            res = create_seller_user(args.api, token, em, nm, ext)
            out_records.append({
                "email": em,
                "full_name": nm,
                "seller_external_id": ext,
                "user_id": res.get("user_id"),
                "seller_id": res.get("seller_id"),
                "temp_password": res.get("temp_password"),
                "status": res.get("status") or ("created" if res.get("temp_password") else "exists"),
            })
        except Exception as e:
            print(f"[ERROR] {em}: {e}", file=sys.stderr)
            out_records.append({
                "email": em,
                "full_name": nm,
                "seller_external_id": ext,
                "user_id": None,
                "seller_id": None,
                "temp_password": None,
                "status": f"error: {e}",
            })
        if args.sleep_ms > 0:
            time.sleep(args.sleep_ms / 1000.0)

    write_output(args.out, out_records)
    print(f"[INFO] Wrote {len(out_records)} rows to {args.out}")
    print("[INFO] Done.")

if __name__ == "__main__":
    main()
